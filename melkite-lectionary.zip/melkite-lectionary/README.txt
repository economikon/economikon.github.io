This is preliminary code.

    
The shortcode is

    [melkite_lectionary]

for the entries for the current date.
    

The shortcode is

    [melkite_lectionary date="string"]

for the entries for a given date attribute.

    
Here are some examples of the output:

<div class='lectionary'>
<div class='major'>Circumcision of our Lord</div>
<div class='orthros'>John 10:1-9</div>
<div class='epistle'>Colossians 2:8-12</div>
<div class='gospel'>Luke 2:20-22,40-52</div>
</div>

<div class='lectionary'>
<div class='minor'>Father Silvester, Pope of Rome</div>
<div class='epistle'>Hebrews 11:17-31</div>
<div class='gospel'>Mark 12:13-17</div>
</div>

<div class='lectionary'>
<div class='major'>Paramony of the Theophany</div>
<div class='minor'>Martyrs Theopemptos and Theonas &#8211; Mother Syncletica</div>
<div class='epistle'>1 Corinthians 9:19-27</div>
<div class='gospel'>Luke 3:1-18</div>
<div class='abstain'>Meat and dairy is not eaten</div>
<div class='timing'>No food from midnight until noon or Vespers</div>
</div>

<div class='lectionary'>
<div class='major'>Theophany of our Lord</div>
<div class='orthros'>Mark 1:9-11</div>
<div class='epistle'>Titus 2:11-14,3:4-7</div>
<div class='gospel'>Matthew 3:13-17</div>
</div>

<div class='lectionary'>
<div class='major'>Sunday After Theophany</div>
<div class='minor'>Venerable Mother Dominica &#8211; Father George the Chosebite</div>
<div class='orthros'>John 20:19-31 (9)</div>
<div class='epistle'>Ephesians 4:7-13</div>
<div class='gospel'>Matthew 4:12-17</div>
</div>

<div class='lectionary'>
<div class='minor'>Apostle Onesimos</div>
<div class='vespers'>Joel 3:12-21, Joel 2:12-26</div>
<div class='abstain'>Meat and dairy is not eaten</div>
<div class='timing'>No food from midnight until noon or Vespers</div>
</div>

<div class='lectionary'>
<div class='minor'>Father Procopios the Decapolitan, Confessor</div>
<div class='vespers'>Genesis 3:21-4:7, Proverbs 3:34-4:22</div>
<div class='6thhour'>Isaiah 4:2-6,5:1-7</div>
<div class='abstain'>Meat and dairy is not eaten</div>
<div class='timing'>No food from midnight until noon or Vespers</div>
</div>
