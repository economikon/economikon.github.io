<?php
/**
* @wordpress-plugin
* Plugin Name:  Melkite Lectionary
* Plugin URI:   https://lectionary.economikon.org
* description:  A plugin that provides the [melkite-lectionary] shortcode
* Version:      1.0
* License:      GPLv2 or later
* License URI:  https://www.gnu.org/licenses/gpl-2.0.html
*/

function melkite_lectionary($atts = [], $content = null, $tag = "") {
  $atts = array_change_key_case((array) $atts, CASE_LOWER);
  $sc_atts = shortcode_atts(array("date" => date("Y-m-d")), $atts, $tag);

  $time = strtotime($sc_atts["date"]);
  if (empty($time)) return ("invalid date: " . $sc_atts["date"]);
  $year = date("Y", strtotime($sc_atts["date"]));
  $suffix = "data/" . $year . ".php";
  $file = __DIR__ . "/" . $suffix;
  if (!file_exists($file)) return ("no such file: " . $suffix);
  include_once($file);

  $className = "Lectionary" . $year;
  $lectionary = new $className();
  $fields = $lectionary->data($sc_atts["date"]);

  $result = "\n<div class='lectionary'>\n";
  $classes = array("major", "minor", "tone", "orthros", "epistle", "gospel", "vespers", "noon", "abstain", "timing");
  foreach ($classes as $class) {
    if (!empty($fields[$class])) $result .= "  <div class='" . $class . "'>" . esc_html($fields[$class]) . "</div>\n";
  };
  $result .= "</div>\n\n";

  return $result;
}

function melkite_lectionary_init() {
  add_shortcode("melkite_lectionary", "melkite_lectionary");
}

add_action("init", "melkite_lectionary_init");
?>
