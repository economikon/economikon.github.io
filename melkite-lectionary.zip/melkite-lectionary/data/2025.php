<?php

class Lectionary2025
{

/*

   $date[$year][$month][$day][$property] = "...";

   $property is any of:

   "major"   / "minor"                        - feast commemoration (either may be empty)

   "orthros"  / "tone" / "epistle" / "gospel" - on Sundays and major feasts
                         "epistle" / "gospel" - otherwise
   "vespers" / "noon"                         - otherwise
   "vespers"                                  - otherwise

   "abstain"                                  - if present, abstinence guideline
   "timing"                                   - if present, timing guideline

*/

  public function data($input = "")
  {
    $time = empty($input) ? time() : strtotime($input);

    $date = array();

    $date[2025][1][1]["major"] = "Circumcision of our Lord";
    $date[2025][1][1]["minor"] = "Saint Basil the Great";
    $date[2025][1][1]["orthros"] = "John 10:1-9";
    $date[2025][1][1]["epistle"] = "Colossians 2:8-12";
    $date[2025][1][1]["gospel"] = "Luke 2:20-21,40-52";

    $date[2025][1][2]["minor"] = "Father Silvester, Pope of Rome";
    $date[2025][1][2]["epistle"] = "Hebrews 5:4-10";
    $date[2025][1][2]["gospel"] = "John 3:1-15";

    $date[2025][1][3]["major"] = "Fast of the Paramony of the Theophany";
    $date[2025][1][3]["minor"] = "Prophet Malachi - Martyr Gordios";
    $date[2025][1][3]["epistle"] = "James 5:10-20";
    $date[2025][1][3]["gospel"] = "John 15:17-16:2";

    $date[2025][1][4]["major"] = "Saturday Before the Theophany of our Lord";
    $date[2025][1][4]["minor"] = "Synaxis of the Seventy Disciples - Father Theoktistos";
    $date[2025][1][4]["epistle"] = "1 Timothy 3:13-16,4:1-5";
    $date[2025][1][4]["gospel"] = "Matthew 3:1-6";

    $date[2025][1][5]["major"] = "Sunday Before the Theophany of our Lord";
    $date[2025][1][5]["minor"] = "Paramony of the Theophany";
    $date[2025][1][5]["tone"] = "Tone 8";
    $date[2025][1][5]["orthros"] = "John 21:14-25 (11)";
    $date[2025][1][5]["epistle"] = "2 Timothy 4:5-8";
    $date[2025][1][5]["gospel"] = "Mark 1:1-8";

    $date[2025][1][6]["major"] = "Theophany of our Lord";
    $date[2025][1][6]["orthros"] = "Mark 1:9-11";
    $date[2025][1][6]["epistle"] = "Titus 2:11-14,3:4-7";
    $date[2025][1][6]["gospel"] = "Matthew 3:13-17";

    $date[2025][1][7]["major"] = "Synaxis of the Forerunner John the Baptist";
    $date[2025][1][7]["epistle"] = "Acts 19:1-8";
    $date[2025][1][7]["gospel"] = "John 1:29-34";

    $date[2025][1][8]["minor"] = "Venerable Mother Dominica - Father George the Chosebite";
    $date[2025][1][8]["epistle"] = "2 Corinthians 4:6-15";
    $date[2025][1][8]["gospel"] = "John 3:22-33";

    $date[2025][1][9]["minor"] = "Martyr Polyeuctos";
    $date[2025][1][9]["epistle"] = "2 Timothy 2:1-10";
    $date[2025][1][9]["gospel"] = "Mark 1:9-15";

    $date[2025][1][10]["minor"] = "Father Gregory of Nyssa - Marcian - Dometian";
    $date[2025][1][10]["epistle"] = "Ephesians 4:7-13";
    $date[2025][1][10]["gospel"] = "Luke 3:19-22";

    $date[2025][1][11]["major"] = "Theodosios the Cenobiarch";
    $date[2025][1][11]["orthros"] = "Luke 6:17-23";
    $date[2025][1][11]["epistle"] = "Hebrews 13:7-16";
    $date[2025][1][11]["gospel"] = "Matthew 4:1-11";

    $date[2025][1][12]["major"] = "Sunday After Theophany";
    $date[2025][1][12]["minor"] = "Martyr Tatiana";
    $date[2025][1][12]["tone"] = "Tone 1";
    $date[2025][1][12]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][1][12]["epistle"] = "Ephesians 4:7-13";
    $date[2025][1][12]["gospel"] = "Matthew 4:12-17";

    $date[2025][1][13]["minor"] = "Martyrs Ermylus and Stratonicos - Martyrs of Sinai and Raitho";
    $date[2025][1][13]["epistle"] = "2 Timothy 2:1-10";
    $date[2025][1][13]["gospel"] = "Luke 20:1-8";

    $date[2025][1][14]["minor"] = "Leave-taking of the Theophany";
    $date[2025][1][14]["epistle"] = "Hebrews 10:32-37";
    $date[2025][1][14]["gospel"] = "Luke 12:32-40";

    $date[2025][1][15]["minor"] = "Fathers Paul of Thebes and John the Hut-dweller";
    $date[2025][1][15]["epistle"] = "Galatians 5:22-26,6:1-2";
    $date[2025][1][15]["gospel"] = "Luke 12:32-40";

    $date[2025][1][16]["major"] = "Veneration of the Chains of the Apostle Peter";
    $date[2025][1][16]["epistle"] = "Acts 12:1-11";
    $date[2025][1][16]["gospel"] = "John 21:14-25";

    $date[2025][1][17]["major"] = "Father Anthony the Great";
    $date[2025][1][17]["orthros"] = "Matthew 11:27-30";
    $date[2025][1][17]["epistle"] = "Hebrews 13:17-21";
    $date[2025][1][17]["gospel"] = "Luke 6:17-23";

    $date[2025][1][18]["major"] = "Fathers Athanasios and Cyril, Archbishops of Alexandria";
    $date[2025][1][18]["orthros"] = "John 10:1-9";
    $date[2025][1][18]["epistle"] = "Hebrews 13:7-16";
    $date[2025][1][18]["gospel"] = "Matthew 5:14-19";

    $date[2025][1][19]["major"] = "Twelfth Sunday After the Holy Cross";
    $date[2025][1][19]["minor"] = "Fathers Macarios the Egyptian and Arsenios";
    $date[2025][1][19]["tone"] = "Tone 2";
    $date[2025][1][19]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][1][19]["epistle"] = "Colossians 3:4-11";
    $date[2025][1][19]["gospel"] = "Luke 17:12-19";

    $date[2025][1][20]["major"] = "Father Euthymios the Great";
    $date[2025][1][20]["orthros"] = "Matthew 11:27-30";
    $date[2025][1][20]["epistle"] = "2 Corinthians 4:6-15";
    $date[2025][1][20]["gospel"] = "Luke 6:17-23";

    $date[2025][1][21]["minor"] = "Father Maximos the Confessor - Martyr Neophyte";
    $date[2025][1][21]["epistle"] = "Philippians 1:12-20";
    $date[2025][1][21]["gospel"] = "Luke 12:8-12";

    $date[2025][1][22]["minor"] = "Apostle Timothy - Martyr Anastasios the Persian";
    $date[2025][1][22]["epistle"] = "2 Timothy 1:3-8";
    $date[2025][1][22]["gospel"] = "Matthew 10:32-33,37-38,19:27-30";

    $date[2025][1][23]["minor"] = "Hiermartyr Clement Bishop of Ancyra - Martyr Agathangel";
    $date[2025][1][23]["epistle"] = "Philippians 3:20-21,4:1-3";
    $date[2025][1][23]["gospel"] = "Mark 2:23-28,3:1-5";

    $date[2025][1][24]["minor"] = "Mother Xenia the Roman";
    $date[2025][1][24]["epistle"] = "Galatians 5:22-26,6:1-2";
    $date[2025][1][24]["gospel"] = "Matthew 25:1-13";

    $date[2025][1][25]["major"] = "Father Gregory the Theologian, Patriarch of Constantinople";
    $date[2025][1][25]["orthros"] = "John 10:1-9";
    $date[2025][1][25]["epistle"] = "Hebrews 7:26-28,8:1-2";
    $date[2025][1][25]["gospel"] = "John 10:9-16";

    $date[2025][1][26]["major"] = "Fifteenth Sunday After the Holy Cross";
    $date[2025][1][26]["minor"] = "Father Xenophon and His Relatives";
    $date[2025][1][26]["tone"] = "Tone 3";
    $date[2025][1][26]["orthros"] = "Mark 16:9-20 (3)";
    $date[2025][1][26]["epistle"] = "1 Timothy 4:9-15";
    $date[2025][1][26]["gospel"] = "Luke 19:1-10";

    $date[2025][1][27]["major"] = "Transfer of the Remains of Father John Chrysostom";
    $date[2025][1][27]["orthros"] = "John 10:1-9";
    $date[2025][1][27]["epistle"] = "Hebrews 7:26-28,8:1-2";
    $date[2025][1][27]["gospel"] = "John 10:9-16";

    $date[2025][1][28]["minor"] = "Father Ephrem and Isaac the Syrians";
    $date[2025][1][28]["epistle"] = "Galatians 5:22-26,6:1-2";
    $date[2025][1][28]["gospel"] = "Luke 6:17-23";

    $date[2025][1][29]["minor"] = "Transfer of the Remains of Hieromartyr Ignatius";
    $date[2025][1][29]["orthros"] = "John 10:9-16";
    $date[2025][1][29]["epistle"] = "Hebrews 10:32-38";
    $date[2025][1][29]["gospel"] = "Mark 9:33-41";

    $date[2025][1][30]["major"] = "Fathers Basil the Great, Gregory the Theologian and John Chrysostom";
    $date[2025][1][30]["minor"] = "Hieromartyr Hippolytus";
    $date[2025][1][30]["orthros"] = "John 10:9-16";
    $date[2025][1][30]["epistle"] = "Hebrews 13:7-16";
    $date[2025][1][30]["gospel"] = "Matthew 5:14-19";

    $date[2025][1][31]["minor"] = "Cyrus and John the Moneyless Wonderworkers";
    $date[2025][1][31]["epistle"] = "1 Corinthians 12:27-31,13:1-7";
    $date[2025][1][31]["gospel"] = "Matthew 10:1,5-8";

    $date[2025][2][1]["major"] = "Preparation of the Encounter";
    $date[2025][2][1]["minor"] = "Martyr Tryphon";
    $date[2025][2][1]["epistle"] = "Romans 8:28-39";
    $date[2025][2][1]["gospel"] = "Luke 10:19-21";

    $date[2025][2][2]["major"] = "Encounter of our Lord";
    $date[2025][2][2]["tone"] = "Tone 4";
    $date[2025][2][2]["orthros"] = "Luke 2:25-32";
    $date[2025][2][2]["epistle"] = "Hebrews 7:7-17";
    $date[2025][2][2]["gospel"] = "Luke 2:22-40";

    $date[2025][2][3]["minor"] = "Simeon the Just and Ann the Prophetess";
    $date[2025][2][3]["epistle"] = "1 Peter 2:21-25,3:1-9";
    $date[2025][2][3]["gospel"] = "Mark 12:13-17";

    $date[2025][2][4]["minor"] = "Father Isidore of Pelusium";
    $date[2025][2][4]["epistle"] = "1 Peter 3:10-22";
    $date[2025][2][4]["gospel"] = "Mark 12:18-27";

    $date[2025][2][5]["minor"] = "Martyr Agatha";
    $date[2025][2][5]["epistle"] = "1 Peter 4:1-11";
    $date[2025][2][5]["gospel"] = "Mark 12:28-37";

    $date[2025][2][6]["minor"] = "Father Boukolos, Bishop of Smyrna, Photios and Martyr Elian of Homs";
    $date[2025][2][6]["epistle"] = "1 Peter 4:12-19,5:1-5";
    $date[2025][2][6]["gospel"] = "Mark 12:38-44";

    $date[2025][2][7]["minor"] = "Father Parthenios and Luke of Hellas";
    $date[2025][2][7]["epistle"] = "2 Peter 1:1-10";
    $date[2025][2][7]["gospel"] = "Mark 13:1-8";

    $date[2025][2][8]["minor"] = "Great-martyr Theodore - Prophet Zekariah";
    $date[2025][2][8]["epistle"] = "2 Timothy 2:11-19";
    $date[2025][2][8]["gospel"] = "Luke 18:2-8";

    $date[2025][2][9]["major"] = "Sunday of the Pharisee and the Publican - Leave-taking of the Encounter";
    $date[2025][2][9]["tone"] = "Tone 5";
    $date[2025][2][9]["orthros"] = "Luke 24:12-35 (5)";
    $date[2025][2][9]["epistle"] = "2 Timothy 3:10-15";
    $date[2025][2][9]["gospel"] = "Luke 18:10-14";

    $date[2025][2][10]["minor"] = "Hieromartyr Charalampos";
    $date[2025][2][10]["epistle"] = "2 Peter 1:20-21,2:1-9";
    $date[2025][2][10]["gospel"] = "Mark 13:9-13";

    $date[2025][2][11]["minor"] = "Hieromartyr Blaise, Bishop of Sebastea and Empress Theodora";
    $date[2025][2][11]["epistle"] = "2 Peter 2:9-22";
    $date[2025][2][11]["gospel"] = "Mark 13:14-23";

    $date[2025][2][12]["minor"] = "Father Meletios, Archbishop of Antioch";
    $date[2025][2][12]["epistle"] = "2 Peter 3:1-18";
    $date[2025][2][12]["gospel"] = "Mark 13:24-31";

    $date[2025][2][13]["minor"] = "Father Martinian";
    $date[2025][2][13]["epistle"] = "1 John 1:8-10,2:1-6";
    $date[2025][2][13]["gospel"] = "Mark 13:31-37,14:1-2";

    $date[2025][2][14]["minor"] = "Father Auxentios - Hermit Maron";
    $date[2025][2][14]["epistle"] = "1 John 2:7-17";
    $date[2025][2][14]["gospel"] = "Mark 14:3-9";

    $date[2025][2][15]["minor"] = "Apostle Onesimos";
    $date[2025][2][15]["epistle"] = "1 Timothy 6:11-16";
    $date[2025][2][15]["gospel"] = "Luke 20:46-47,21:1-4";

    $date[2025][2][16]["major"] = "Sunday of the Prodigal Son";
    $date[2025][2][16]["minor"] = "Martyrs Pamphilos and His Companions";
    $date[2025][2][16]["tone"] = "Tone 6";
    $date[2025][2][16]["orthros"] = "Luke 24:36-53 (6)";
    $date[2025][2][16]["epistle"] = "1 Corinthians 6:12-20";
    $date[2025][2][16]["gospel"] = "Luke 15:11-32";

    $date[2025][2][17]["minor"] = "Great-martyr Theodore";
    $date[2025][2][17]["epistle"] = "1 John 2:18-29,3:1-8";
    $date[2025][2][17]["gospel"] = "Mark 11:1-11";

    $date[2025][2][18]["minor"] = "Father Leo, Pope of Rome";
    $date[2025][2][18]["epistle"] = "1 John 3:9-22";
    $date[2025][2][18]["gospel"] = "Mark 14:10-42";

    $date[2025][2][19]["minor"] = "Apostle Archippos - Martyr Philothea";
    $date[2025][2][19]["epistle"] = "1 John 3:21-24,4:1-11";
    $date[2025][2][19]["gospel"] = "Mark 14:43-72,15:1";

    $date[2025][2][20]["minor"] = "Father Leo, Bishop of Catania";
    $date[2025][2][20]["epistle"] = "1 John 4:20-21,5:1-21";
    $date[2025][2][20]["gospel"] = "Mark 15:1-15";

    $date[2025][2][21]["minor"] = "Fathers Timothy and Eustathios, Archbishop of Antioch";
    $date[2025][2][21]["epistle"] = "2 John 1:1-13";
    $date[2025][2][21]["gospel"] = "Mark 15:22,25,33-41";

    $date[2025][2][22]["major"] = "Saturday of the Dead";
    $date[2025][2][22]["minor"] = "Discovery of the Remains of the Martyrs at Eugenios";
    $date[2025][2][22]["epistle"] = "1 Corinthians 10:23-29";
    $date[2025][2][22]["gospel"] = "Luke 21:8-9,25-27,33-36";

    $date[2025][2][23]["major"] = "Sunday of Meat-fare";
    $date[2025][2][23]["tone"] = "Tone 7";
    $date[2025][2][23]["orthros"] = "John 20:1-10 (7)";
    $date[2025][2][23]["epistle"] = "1 Corinthians 8:8-13,9:1-2";
    $date[2025][2][23]["gospel"] = "Matthew 25:31-46";

    $date[2025][2][24]["major"] = "First and Second Discoveries of the Head of the Forerunner";
    $date[2025][2][24]["orthros"] = "Luke 7:17-30";
    $date[2025][2][24]["epistle"] = "2 Corinthians 4:6-15";
    $date[2025][2][24]["gospel"] = "Matthew 11:2-15";

    $date[2025][2][25]["minor"] = "Tarasios of Constantinople";
    $date[2025][2][25]["epistle"] = "Jude 1:1-10";
    $date[2025][2][25]["gospel"] = "Luke 22:39-42,45-71,23:1";

    $date[2025][2][26]["minor"] = "Father Porphyrios, Bishop of Gaza and Photini the Samaritan Woman";
    $date[2025][2][26]["vespers"] = "Joel 3:12-21, Joel 2:12-26";

    $date[2025][2][27]["minor"] = "Father Procopios the Decapolitan, Confessor";
    $date[2025][2][27]["epistle"] = "Jude 1:11-25";
    $date[2025][2][27]["gospel"] = "Luke 23:1-33,44-56";

    $date[2025][2][28]["minor"] = "Father Basil, Confessor";
    $date[2025][2][28]["vespers"] = "Zechariah 8:19-23, Zechariah 8:7-17";

    $date[2025][3][1]["major"] = "Saturday of our God-bearing Fathers the Ascetics";
    $date[2025][3][1]["minor"] = "Martyr Eudocia";
    $date[2025][3][1]["epistle"] = "Romans 14:19-23,16:25-27";
    $date[2025][3][1]["gospel"] = "Matthew 6:1-13";

    $date[2025][3][2]["major"] = "Sunday of Cheese-fare";
    $date[2025][3][2]["tone"] = "Tone 8";
    $date[2025][3][2]["orthros"] = "John 20:11-18 (8)";
    $date[2025][3][2]["epistle"] = "Romans 13:11-14,14:1-4";
    $date[2025][3][2]["gospel"] = "Matthew 6:14-21";

    $date[2025][3][3]["major"] = "Great Fast Begins";
    $date[2025][3][3]["minor"] = "Martyrs Eutropius, Cleonicus, and Basiliscus";
    $date[2025][3][3]["noon"] = "Isaiah 1:1-20";
    $date[2025][3][3]["vespers"] = "Genesis 1:1-13, Proverbs 1:1-20";

    $date[2025][3][4]["minor"] = "Father Gerasimos the Jordanite";
    $date[2025][3][4]["noon"] = "Isaiah 1:19-2:3";
    $date[2025][3][4]["vespers"] = "Genesis 1:14-23, Proverbs 1:20-33";

    $date[2025][3][5]["minor"] = "Martyr Conon of Isauria";
    $date[2025][3][5]["noon"] = "Isaiah 2:3-11";
    $date[2025][3][5]["vespers"] = "Genesis 1:24-2:3, Proverbs 2:1-22";

    $date[2025][3][6]["minor"] = "Forty-two Martyrs of Amorium";
    $date[2025][3][6]["noon"] = "Isaiah 2:11-21";
    $date[2025][3][6]["vespers"] = "Genesis 2:4-19, Proverbs 3:1-18";

    $date[2025][3][7]["minor"] = "Hieromartyrs Ephrem, Basil, Eugene, Agathodore, Capiton, Aitheres and Elpides";
    $date[2025][3][7]["noon"] = "Isaiah 3:1-14";
    $date[2025][3][7]["vespers"] = "Genesis 2:20-3:20, Proverbs 3:19-34";

    $date[2025][3][8]["major"] = "Saturday of the Great Among the Martyrs Theodore";
    $date[2025][3][8]["epistle"] = "Hebrews 1:1-12";
    $date[2025][3][8]["gospel"] = "Mark 2:23-28,3:1-5";

    $date[2025][3][9]["major"] = "Sunday of Orthodoxy";
    $date[2025][3][9]["tone"] = "Tone 1";
    $date[2025][3][9]["orthros"] = "John 20:19-31 (9)";
    $date[2025][3][9]["epistle"] = "Hebrews 12:1-10";
    $date[2025][3][9]["gospel"] = "John 1:43-51";

    $date[2025][3][10]["minor"] = "Martyrs Codratos of Corinth and His Companions";
    $date[2025][3][10]["noon"] = "Isaiah 4:2-6,5:1-7";
    $date[2025][3][10]["vespers"] = "Genesis 3:21-4:7, Proverbs 3:34-4:22";

    $date[2025][3][11]["minor"] = "Father Sophronios, Patriarch of Jerusalem";
    $date[2025][3][11]["noon"] = "Isaiah 5:7-16";
    $date[2025][3][11]["vespers"] = "Genesis 4:8-15, Proverbs 5:1-15";

    $date[2025][3][12]["minor"] = "Fathers Theophane, Confessor and Gregory the Great, Pope of Rome";
    $date[2025][3][12]["noon"] = "Isaiah 5:16-25";
    $date[2025][3][12]["vespers"] = "Genesis 4:16-26, Proverbs 5:15-6:4";

    $date[2025][3][13]["minor"] = "Deposition of the Remains of Nicephoros, Patriarch of Constantinople";
    $date[2025][3][13]["noon"] = "Isaiah 6:1-12";
    $date[2025][3][13]["vespers"] = "Genesis 5:1-24, Proverbs 6:3-20";

    $date[2025][3][14]["minor"] = "Father Benedict of Nursia";
    $date[2025][3][14]["noon"] = "Isaiah 7:1-14";
    $date[2025][3][14]["vespers"] = "Genesis 5:32-6:8, Proverbs 6:20-7:1";

    $date[2025][3][15]["minor"] = "Martyrs Agapios and His Seven Companions";
    $date[2025][3][15]["epistle"] = "Hebrews 3:12-16";
    $date[2025][3][15]["gospel"] = "Mark 1:35-44";

    $date[2025][3][16]["major"] = "Sunday of the Holy Relics and Saint Gregory Palamas";
    $date[2025][3][16]["tone"] = "Tone 2";
    $date[2025][3][16]["orthros"] = "John 21:1-14 (10)";
    $date[2025][3][16]["epistle"] = "Hebrews 1:10-14,2:1-3";
    $date[2025][3][16]["gospel"] = "Mark 2:1-12";

    $date[2025][3][17]["minor"] = "Father Alexis, the Man of God";
    $date[2025][3][17]["noon"] = "Isaiah 8:13-22,9:1-7";
    $date[2025][3][17]["vespers"] = "Genesis 6:9-22, Proverbs 8:1-21";

    $date[2025][3][18]["minor"] = "Father Cyril, Archbishop of Jerusalem";
    $date[2025][3][18]["noon"] = "Isaiah 9:9-21,10:1-4";
    $date[2025][3][18]["vespers"] = "Genesis 7:1-5, Proverbs 8:32-9:11";

    $date[2025][3][19]["minor"] = "Martyrs Chrysanthos and Daria";
    $date[2025][3][19]["noon"] = "Isaiah 10:12-20";
    $date[2025][3][19]["vespers"] = "Genesis 7:6-9, Proverbs 9:12-18";

    $date[2025][3][20]["minor"] = "Martyrs of the Monastery of St. Sabas";
    $date[2025][3][20]["noon"] = "Isaiah 11:10-16,12:1-2";
    $date[2025][3][20]["vespers"] = "Genesis 7:11-8:3, Proverbs 10:1-22";

    $date[2025][3][21]["minor"] = "Father James, Bishop of Catania, Confessor";
    $date[2025][3][21]["noon"] = "Isaiah 13:2-13";
    $date[2025][3][21]["vespers"] = "Genesis 8:4-21, Proverbs 10:31-11:12";

    $date[2025][3][22]["minor"] = "Hieromartyr Basil, Priest of the Church of Ancyra";
    $date[2025][3][22]["epistle"] = "Hebrews 10:32-38";
    $date[2025][3][22]["gospel"] = "Mark 2:14-17";

    $date[2025][3][23]["major"] = "Sunday of the Holy Cross";
    $date[2025][3][23]["tone"] = "Tone 3";
    $date[2025][3][23]["orthros"] = "John 21:14-25 (11)";
    $date[2025][3][23]["epistle"] = "Hebrews 4:14-16,5:1-6";
    $date[2025][3][23]["gospel"] = "Mark 8:34-38,9:1";

    $date[2025][3][24]["major"] = "Preparation of the Annunciation";
    $date[2025][3][24]["minor"] = "Father Zachary the Recluse";
    $date[2025][3][24]["noon"] = "Isaiah 14:24-32";
    $date[2025][3][24]["vespers"] = "Genesis 8:21-9:7, Proverbs 11:19-12:6";

    $date[2025][3][25]["major"] = "Annunciation of the Mother of God";
    $date[2025][3][25]["orthros"] = "Luke 1:39-49,56";
    $date[2025][3][25]["epistle"] = "Hebrews 2:11-18";
    $date[2025][3][25]["gospel"] = "Luke 1:24-38";

    $date[2025][3][26]["major"] = "Synaxis of the Archangel Gabriel";
    $date[2025][3][26]["epistle"] = "Hebrews 2:2-10";
    $date[2025][3][26]["gospel"] = "Luke 10:16-21";

    $date[2025][3][27]["minor"] = "Mother Matrona of Salonica";
    $date[2025][3][27]["noon"] = "Isaiah 28:14-22";
    $date[2025][3][27]["vespers"] = "Genesis 10:32-11:9, Proverbs 13:19-14:6";

    $date[2025][3][28]["minor"] = "Fathers Stephen the Wonderworker and Hilarion the Younger";
    $date[2025][3][28]["noon"] = "Isaiah 29:13-23";
    $date[2025][3][28]["vespers"] = "Genesis 12:1-7, Proverbs 14:15-26";

    $date[2025][3][29]["minor"] = "Hieromartyrs Mark, Bishop of Amethusa, His Deacon Cyril and Their Companions";
    $date[2025][3][29]["epistle"] = "Hebrews 6:9-12";
    $date[2025][3][29]["gospel"] = "Mark 7:31-37";

    $date[2025][3][30]["major"] = "Sunday of our Father John Climacus";
    $date[2025][3][30]["tone"] = "Tone 4";
    $date[2025][3][30]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][3][30]["epistle"] = "Hebrews 6:13-20";
    $date[2025][3][30]["gospel"] = "Mark 9:17-31";

    $date[2025][3][31]["minor"] = "Father Hypatios the Wonderworker, Bishop of Gangra";
    $date[2025][3][31]["noon"] = "Isaiah 37:33-38,38:1-6";
    $date[2025][3][31]["vespers"] = "Genesis 13:12-18, Proverbs 14:27-15:4";

    $date[2025][4][1]["minor"] = "Mother Mary the Egyptian";
    $date[2025][4][1]["noon"] = "Isaiah 40:18-31";
    $date[2025][4][1]["vespers"] = "Genesis 15:1-15, Proverbs 15:7-19";

    $date[2025][4][2]["minor"] = "Father Titus the Wonderworker";
    $date[2025][4][2]["noon"] = "Isaiah 41:4-14";
    $date[2025][4][2]["vespers"] = "Genesis 17:1-9, Proverbs 15:20-16:9";

    $date[2025][4][3]["major"] = "Thursday of Repentance";
    $date[2025][4][3]["minor"] = "Father Nicetas, Abbot of the Monastery of Medicium, Confessor";
    $date[2025][4][3]["noon"] = "Isaiah 42:5-16";
    $date[2025][4][3]["vespers"] = "Genesis 18:20-33, Proverbs 16:17-17:17";

    $date[2025][4][4]["minor"] = "Martyrs Theodule and Agatdhopode - Fathers George of Maleum and Joseph the Hymnographer";
    $date[2025][4][4]["noon"] = "Isaiah 45:11-17";
    $date[2025][4][4]["vespers"] = "Genesis 22:1-18, Proverbs 17:17-18:5";

    $date[2025][4][5]["major"] = "Saturday of the Acathist Hymn";
    $date[2025][4][5]["epistle"] = "Hebrews 9:24-28";
    $date[2025][4][5]["gospel"] = "Mark 8:27-31";

    $date[2025][4][6]["major"] = "Sunday of Mary of Egypt";
    $date[2025][4][6]["minor"] = "Father Eutychios, Archbishop of Constantinople";
    $date[2025][4][6]["tone"] = "Tone 5";
    $date[2025][4][6]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][4][6]["epistle"] = "Hebrews 9:11-14";
    $date[2025][4][6]["gospel"] = "Mark 10:32-45";

    $date[2025][4][7]["minor"] = "Martyr Kalliopos - Father George, Bishop of Melitene";
    $date[2025][4][7]["noon"] = "Isaiah 48:17-22,49:1-4";
    $date[2025][4][7]["vespers"] = "Genesis 27:1-41, Proverbs 19:16-25";

    $date[2025][4][8]["minor"] = "Apostles Herodion, Agabus, Rufus, Asyncritus, Phlegon and Hermes";
    $date[2025][4][8]["noon"] = "Isaiah 49:6-10";
    $date[2025][4][8]["vespers"] = "Genesis 31:3-16, Proverbs 21:3-21";

    $date[2025][4][9]["minor"] = "Martyr Eupsichius of Caesarea";
    $date[2025][4][9]["noon"] = "Isaiah 58:1-11";
    $date[2025][4][9]["vespers"] = "Genesis 43:26-31,45:1-16, Proverbs 21:23-22:4";

    $date[2025][4][10]["minor"] = "Martyrs Terence, Pompeius, Maximos and Their Companions";
    $date[2025][4][10]["noon"] = "Isaiah 65:8-16";
    $date[2025][4][10]["vespers"] = "Genesis 46:1-7, Proverbs 23:15-24:5";

    $date[2025][4][11]["minor"] = "Hieromartyr Antipas, Bishop of Pergamum in Asia";
    $date[2025][4][11]["noon"] = "Isaiah 66:10-24";
    $date[2025][4][11]["vespers"] = "Genesis 49:33-50:26, Proverbs 31:8-31";

    $date[2025][4][12]["major"] = "Saturday of Lazarus";
    $date[2025][4][12]["epistle"] = "Hebrews 12:28-29,13:8";
    $date[2025][4][12]["gospel"] = "John 11:1-45";

    $date[2025][4][13]["major"] = "Palm Sunday";
    $date[2025][4][13]["orthros"] = "Matthew 21:1-11,15-17";
    $date[2025][4][13]["epistle"] = "Philippians 4:4-9";
    $date[2025][4][13]["gospel"] = "John 12:1-18";

    $date[2025][4][14]["major"] = "Great and Holy Monday";
    $date[2025][4][14]["orthros"] = "Matthew 21:18-43";
    $date[2025][4][14]["epistle"] = "Romans 11:13-24";
    $date[2025][4][14]["gospel"] = "Matthew 24:3-35";

    $date[2025][4][15]["major"] = "Great and Holy Tuesday";
    $date[2025][4][15]["orthros"] = "Matthew 22:15-46,23:13-39";
    $date[2025][4][15]["epistle"] = "Ephesians 1:1-9";
    $date[2025][4][15]["gospel"] = "Matthew 24:36-51,25:1-46,26:1-2";

    $date[2025][4][16]["major"] = "Great and Holy Wednesday";
    $date[2025][4][16]["orthros"] = "John 12:17-50";
    $date[2025][4][16]["epistle"] = "1 Corinthians 2:6-9";
    $date[2025][4][16]["gospel"] = "Matthew 26:6-16";

    $date[2025][4][17]["major"] = "Great and Holy Thursday";
    $date[2025][4][17]["orthros"] = "Luke 22:1-39";
    $date[2025][4][17]["epistle"] = "1 Corinthians 11:23-32";
    $date[2025][4][17]["gospel"] = "Matthew 26:1-20; John 13:3-18; Matthew 26:21-39; Luke 22:43-44; Matthew 26:40-75,27:1-2";

    $date[2025][4][18]["major"] = "Great and Holy Friday";
    $date[2025][4][18]["epistle"] = "1 Corinthians 15:47-58";
    $date[2025][4][18]["gospel"] = "John 6:48-55";

    $date[2025][4][19]["major"] = "Great and Holy Saturday";
    $date[2025][4][19]["orthros"] = "Matthew 27:62-66";
    $date[2025][4][19]["epistle"] = "Romans 6:3-11";
    $date[2025][4][19]["gospel"] = "Matthew 28:1-20";

    $date[2025][4][20]["major"] = "Holy Resurrection";
    $date[2025][4][20]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][4][20]["epistle"] = "Acts 1:1-8";
    $date[2025][4][20]["gospel"] = "John 1:1-17";

    $date[2025][4][21]["major"] = "Bright Monday";
    $date[2025][4][21]["epistle"] = "Acts 1:12-17,21-26";
    $date[2025][4][21]["gospel"] = "John 1:18-28";

    $date[2025][4][22]["major"] = "Bright Tuesday";
    $date[2025][4][22]["epistle"] = "Acts 2:14-21";
    $date[2025][4][22]["gospel"] = "Luke 24:12-35";

    $date[2025][4][23]["major"] = "Bright Wednesday";
    $date[2025][4][23]["minor"] = "Great-martyr George the Triumphant";
    $date[2025][4][23]["orthros"] = "Luke 21:12-19";
    $date[2025][4][23]["epistle"] = "Galatians 3:23-29,4:1-5";
    $date[2025][4][23]["gospel"] = "John 1:35-51";

    $date[2025][4][24]["major"] = "Bright Thursday";
    $date[2025][4][24]["epistle"] = "Acts 2:38-43";
    $date[2025][4][24]["gospel"] = "John 3:1-15";

    $date[2025][4][25]["major"] = "Bright Friday";
    $date[2025][4][25]["minor"] = "Apostle Mark the Evangelist";
    $date[2025][4][25]["epistle"] = "Acts 3:1-8";
    $date[2025][4][25]["gospel"] = "Luke 10:16-21";

    $date[2025][4][26]["major"] = "Bright Saturday";
    $date[2025][4][26]["epistle"] = "Acts 3:9-16";
    $date[2025][4][26]["gospel"] = "John 3:22-33";

    $date[2025][4][27]["major"] = "Sunday of St. Thomas";
    $date[2025][4][27]["tone"] = "Tone 1";
    $date[2025][4][27]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][4][27]["epistle"] = "Acts 5:12-20";
    $date[2025][4][27]["gospel"] = "John 20:19-31";

    $date[2025][4][28]["minor"] = "Disciples Jason and Sosipater - Father Cyril, Bishop of Turov";
    $date[2025][4][28]["epistle"] = "Acts 3:19-26";
    $date[2025][4][28]["gospel"] = "John 2:1-11";

    $date[2025][4][29]["minor"] = "Martyrs of Cyzica and Memnon the Wonderworker";
    $date[2025][4][29]["epistle"] = "Acts 4:1-10";
    $date[2025][4][29]["gospel"] = "John 3:16-21";

    $date[2025][4][30]["major"] = "Apostle James, Brother of John the Evangelist";
    $date[2025][4][30]["epistle"] = "Acts 12:1-11";
    $date[2025][4][30]["gospel"] = "Luke 9:1-6";

    $date[2025][5][1]["minor"] = "Prophet Jeremiah";
    $date[2025][5][1]["epistle"] = "Acts 4:23-31";
    $date[2025][5][1]["gospel"] = "John 5:24-30";

    $date[2025][5][2]["major"] = "Transfer of the Remains of Athanasios the Great";
    $date[2025][5][2]["epistle"] = "Hebrews 13:7-16";
    $date[2025][5][2]["gospel"] = "Matthew 5:14-19";

    $date[2025][5][3]["major"] = "Leave-taking of St. Thomas";
    $date[2025][5][3]["minor"] = "Martyrs Timothy and Maura";
    $date[2025][5][3]["epistle"] = "Acts 5:21-32";
    $date[2025][5][3]["gospel"] = "John 6:14-27";

    $date[2025][5][4]["major"] = "Sunday of Ointment-bearing Women";
    $date[2025][5][4]["tone"] = "Tone 2";
    $date[2025][5][4]["orthros"] = "Luke 24:1-12 (4)";
    $date[2025][5][4]["epistle"] = "Acts 6:1-7";
    $date[2025][5][4]["gospel"] = "Mark 15:43-47,16:1-8";

    $date[2025][5][5]["minor"] = "Martyr Irene";
    $date[2025][5][5]["epistle"] = "Acts 6:8-15,7:1-5,47-60";
    $date[2025][5][5]["gospel"] = "John 4:46-54";

    $date[2025][5][6]["minor"] = "Job, the Holy and Long-suffering One";
    $date[2025][5][6]["epistle"] = "Acts 8:5-15";
    $date[2025][5][6]["gospel"] = "John 6:27-33";

    $date[2025][5][7]["minor"] = "Apparition of the Cross Over Jerusalem";
    $date[2025][5][7]["epistle"] = "Acts 8:18-25";
    $date[2025][5][7]["gospel"] = "John 6:35-39";

    $date[2025][5][8]["major"] = "Apostle and Evangelist John the Theologian";
    $date[2025][5][8]["minor"] = "Father Arsenios the Great";
    $date[2025][5][8]["orthros"] = "John 21:14-25 (11)";
    $date[2025][5][8]["epistle"] = "1 John 1:1-7";
    $date[2025][5][8]["gospel"] = "John 19:25-27,21:24-25";

    $date[2025][5][9]["minor"] = "Prophet Isaiah and Martyr Christopher";
    $date[2025][5][9]["epistle"] = "Acts 8:40,9:1-19";
    $date[2025][5][9]["gospel"] = "John 6:48-55";

    $date[2025][5][10]["minor"] = "Apostle Simon the Zealot";
    $date[2025][5][10]["epistle"] = "Acts 9:19-31";
    $date[2025][5][10]["gospel"] = "John 15:17-27,16:1-2";

    $date[2025][5][11]["major"] = "Sunday of the Paralytic";
    $date[2025][5][11]["tone"] = "Tone 3";
    $date[2025][5][11]["orthros"] = "Luke 24:12-35 (5)";
    $date[2025][5][11]["epistle"] = "Acts 9:32-42";
    $date[2025][5][11]["gospel"] = "John 5:1-15";

    $date[2025][5][12]["minor"] = "Fathers Epiphanios, Bishop of Cyprus - Germanos the Hymnographer, Patriarch of Constantinople";
    $date[2025][5][12]["epistle"] = "Acts 10:1-16";
    $date[2025][5][12]["gospel"] = "John 6:56-69";

    $date[2025][5][13]["minor"] = "Martyr Glyceria";
    $date[2025][5][13]["epistle"] = "Acts 10:21-33";
    $date[2025][5][13]["gospel"] = "John 7:1-13";

    $date[2025][5][14]["major"] = "Mid-pentecost";
    $date[2025][5][14]["epistle"] = "Acts 14:6-18";
    $date[2025][5][14]["gospel"] = "John 7:14-30";

    $date[2025][5][15]["minor"] = "Fathers Pachomios the Great and Achillios the Wonderworker";
    $date[2025][5][15]["epistle"] = "Acts 10:34-43";
    $date[2025][5][15]["gospel"] = "John 8:12-20";

    $date[2025][5][16]["minor"] = "Father Theodore the Sanctified";
    $date[2025][5][16]["epistle"] = "Acts 10:44-48,11:1-10";
    $date[2025][5][16]["gospel"] = "John 8:21-30";

    $date[2025][5][17]["minor"] = "Apostles Andronicos and Junias";
    $date[2025][5][17]["epistle"] = "Acts 12:1-11";
    $date[2025][5][17]["gospel"] = "John 8:31-42";

    $date[2025][5][18]["major"] = "Sunday of the Samaritan Woman";
    $date[2025][5][18]["tone"] = "Tone 4";
    $date[2025][5][18]["orthros"] = "John 20:1-10 (7)";
    $date[2025][5][18]["epistle"] = "Acts 11:19-30";
    $date[2025][5][18]["gospel"] = "John 4:5-42";

    $date[2025][5][19]["minor"] = "Hieromartyr Patrick, Bishop of Prussa and His Companions";
    $date[2025][5][19]["epistle"] = "Acts 12:12-17";
    $date[2025][5][19]["gospel"] = "John 8:42-51";

    $date[2025][5][20]["minor"] = "Martyr Thallelaius";
    $date[2025][5][20]["epistle"] = "Acts 12:25,13:1-12";
    $date[2025][5][20]["gospel"] = "John 8:51-59";

    $date[2025][5][21]["major"] = "Leave-taking of Mid-pentecost";
    $date[2025][5][21]["minor"] = "The Equals of the Apostles Constantine and Helena";
    $date[2025][5][21]["orthros"] = "John 10:9-16";
    $date[2025][5][21]["epistle"] = "Acts 26:1,12-20";
    $date[2025][5][21]["gospel"] = "John 10:1-9";

    $date[2025][5][22]["minor"] = "Martyr Basiliscus";
    $date[2025][5][22]["epistle"] = "Acts 14:20-28,15:1-4";
    $date[2025][5][22]["gospel"] = "John 9:39-41,10:1-9";

    $date[2025][5][23]["minor"] = "Father Michael the Confessor, Metropolitan of Synades - Mother Euphrosyne of Polotsk";
    $date[2025][5][23]["epistle"] = "Acts 15:5-12";
    $date[2025][5][23]["gospel"] = "John 10:17-28";

    $date[2025][5][24]["minor"] = "Father Simeon the Younger";
    $date[2025][5][24]["epistle"] = "Acts 15:35-41";
    $date[2025][5][24]["gospel"] = "John 10:27-38";

    $date[2025][5][25]["major"] = "Sunday of the Man Born Blind";
    $date[2025][5][25]["minor"] = "Third Finding of the Head of the Forerunner";
    $date[2025][5][25]["tone"] = "Tone 5";
    $date[2025][5][25]["orthros"] = "John 20:11-18 (8)";
    $date[2025][5][25]["epistle"] = "2 Corinthians 4:6-15";
    $date[2025][5][25]["gospel"] = "John 9:1-38";

    $date[2025][5][26]["minor"] = "Apostle Carpus";
    $date[2025][5][26]["epistle"] = "Acts 17:1-9";
    $date[2025][5][26]["gospel"] = "John 11:47-54";

    $date[2025][5][27]["minor"] = "Hieromartyr Alladius";
    $date[2025][5][27]["epistle"] = "Acts 17:19-28";
    $date[2025][5][27]["gospel"] = "John 12:19-36";

    $date[2025][5][28]["major"] = "Leave-taking of Easter";
    $date[2025][5][28]["epistle"] = "Acts 18:22-28";
    $date[2025][5][28]["gospel"] = "John 12:36-47";

    $date[2025][5][29]["major"] = "Feast of the Ascension";
    $date[2025][5][29]["minor"] = "Martyr Theodosia of Tyre";
    $date[2025][5][29]["orthros"] = "Mark 16:9-20 (3)";
    $date[2025][5][29]["epistle"] = "Acts 1:1-12";
    $date[2025][5][29]["gospel"] = "Luke 24:36-53";

    $date[2025][5][30]["major"] = "";
    $date[2025][5][30]["minor"] = "Father Isaac, Abbot";
    $date[2025][5][30]["epistle"] = "Acts 19:1-8";
    $date[2025][5][30]["gospel"] = "John 14:1-11";

    $date[2025][5][31]["minor"] = "Martyr Hermius";
    $date[2025][5][31]["epistle"] = "Acts 20:7-12";
    $date[2025][5][31]["gospel"] = "John 14:10-21";

    $date[2025][6][1]["major"] = "Sunday of the Fathers of Nicea I";
    $date[2025][6][1]["tone"] = "Tone 6";
    $date[2025][6][1]["orthros"] = "John 21:1-14 (10)";
    $date[2025][6][1]["epistle"] = "Acts 20:16-18,27-36";
    $date[2025][6][1]["gospel"] = "John 17:1-13";

    $date[2025][6][2]["minor"] = "Father Nicephoros the Confessor, Archbishop of Constantinople";
    $date[2025][6][2]["epistle"] = "Acts 21:8-14";
    $date[2025][6][2]["gospel"] = "John 14:27-31,15:1-7";

    $date[2025][6][3]["minor"] = "Martyrs Lucillian and His Companions";
    $date[2025][6][3]["epistle"] = "Acts 21:26-32";
    $date[2025][6][3]["gospel"] = "John 16:2-13";

    $date[2025][6][4]["minor"] = "Father Metrophanes, Bishop of Constantinople";
    $date[2025][6][4]["epistle"] = "Acts 23:1-11";
    $date[2025][6][4]["gospel"] = "John 16:15-23";

    $date[2025][6][5]["minor"] = "Hieromartyr Dorotheos, Bishop of Tyre";
    $date[2025][6][5]["epistle"] = "Acts 25:13-19";
    $date[2025][6][5]["gospel"] = "John 16:23-33";

    $date[2025][6][6]["major"] = "Leave-taking of the Ascension";
    $date[2025][6][6]["minor"] = "Fathers Bessarion the Wonderworker and Hilarion the Younger, Abbot";
    $date[2025][6][6]["epistle"] = "Acts 27:1-44,28:1";
    $date[2025][6][6]["gospel"] = "John 17:18-26";

    $date[2025][6][7]["major"] = "Saturday of the Dead";
    $date[2025][6][7]["minor"] = "Hieromartyr Theodotos, Bishop of Ancyra";
    $date[2025][6][7]["epistle"] = "Acts 28:1-31";
    $date[2025][6][7]["gospel"] = "John 21:14-25";

    $date[2025][6][8]["major"] = "Sunday of Pentecost";
    $date[2025][6][8]["tone"] = "Tone 7";
    $date[2025][6][8]["orthros"] = "John 20:19-23";
    $date[2025][6][8]["epistle"] = "Acts 2:1-11";
    $date[2025][6][8]["gospel"] = "John 7:37-52,8:12";

    $date[2025][6][9]["major"] = "Monday of the Holy Spirit";
    $date[2025][6][9]["minor"] = "Father Cryil, Archbishop of Alexandria";
    $date[2025][6][9]["epistle"] = "Ephesians 5:8-19";
    $date[2025][6][9]["gospel"] = "Matthew 18:10-20";

    $date[2025][6][10]["minor"] = "Martyrs Alexander and Antonina - Hieromartyr Timothy, Bishop of Prussa";
    $date[2025][6][10]["epistle"] = "Romans 1:1-7,13-17";
    $date[2025][6][10]["gospel"] = "Matthew 4:25,5:1-12";

    $date[2025][6][11]["minor"] = "Apostles Bartholomew and Barnabas";
    $date[2025][6][11]["epistle"] = "Romans 1:18-27";
    $date[2025][6][11]["gospel"] = "Matthew 5:20-26";

    $date[2025][6][12]["minor"] = "Fathers Onuphrios of Egypt and Peter of Athos";
    $date[2025][6][12]["epistle"] = "Romans 1:28-32,2:1-9";
    $date[2025][6][12]["gospel"] = "Matthew 5:27-32";

    $date[2025][6][13]["minor"] = "Martyr Aquilina - Father Truphillios, Bishop of Leucosia";
    $date[2025][6][13]["epistle"] = "Romans 2:14-28";
    $date[2025][6][13]["gospel"] = "Matthew 5:33-41";

    $date[2025][6][14]["major"] = "Leave-taking of Pentecost";
    $date[2025][6][14]["minor"] = "Prophet Elisha - Father Methodius, Archbishop of Constantinople";
    $date[2025][6][14]["epistle"] = "Romans 1:7-12";
    $date[2025][6][14]["gospel"] = "Matthew 5:42-48";

    $date[2025][6][15]["major"] = "Sunday of All Saints";
    $date[2025][6][15]["tone"] = "Tone 8";
    $date[2025][6][15]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][6][15]["epistle"] = "Hebrews 11:33-40,12:1-2";
    $date[2025][6][15]["gospel"] = "Matthew 10:32-33,37-38,19:27-30";

    $date[2025][6][16]["minor"] = "Father Tykhon the Wonderworker, Bishop of Amathonte of Cyprus";
    $date[2025][6][16]["epistle"] = "Romans 2:28-29,3:1-18";
    $date[2025][6][16]["gospel"] = "Matthew 6:31-34,7:9-11";

    $date[2025][6][17]["minor"] = "Martyrs Manuel, Sabel and Ismael";
    $date[2025][6][17]["epistle"] = "Romans 4:4-12";
    $date[2025][6][17]["gospel"] = "Matthew 7:15-21";

    $date[2025][6][18]["minor"] = "Martyr Leontius";
    $date[2025][6][18]["epistle"] = "Romans 4:13-25";
    $date[2025][6][18]["gospel"] = "Matthew 7:21-23";

    $date[2025][6][19]["major"] = "Feast of the Divine Body";
    $date[2025][6][19]["minor"] = "Holy Apostle Jude";
    $date[2025][6][19]["orthros"] = "John 6:55-59";
    $date[2025][6][19]["epistle"] = "1 Corinthians 11:23-32";
    $date[2025][6][19]["gospel"] = "John 6:48-55";

    $date[2025][6][20]["minor"] = "Hieromartyr Methodius of Patara";
    $date[2025][6][20]["epistle"] = "Romans 5:17-21,6:1-2";
    $date[2025][6][20]["gospel"] = "Matthew 9:14-17";

    $date[2025][6][21]["minor"] = "Martyr Julian of Tarsus";
    $date[2025][6][21]["epistle"] = "Romans 3:19-26";
    $date[2025][6][21]["gospel"] = "Matthew 7:1-8";

    $date[2025][6][22]["major"] = "Second Sunday After Pentecost";
    $date[2025][6][22]["minor"] = "Martyr Eusebius, Bishop of Samosate";
    $date[2025][6][22]["tone"] = "Tone 1";
    $date[2025][6][22]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][6][22]["epistle"] = "Romans 2:10-16";
    $date[2025][6][22]["gospel"] = "Matthew 4:18-23";

    $date[2025][6][23]["major"] = "Visitation of the Theotokos To Her Cousin Elizabeth";
    $date[2025][6][23]["minor"] = "Martyr Agrippina";
    $date[2025][6][23]["epistle"] = "Galatians 4:4-7";
    $date[2025][6][23]["gospel"] = "Luke 1:29-45";

    $date[2025][6][24]["major"] = "Nativity of the Forerunner";
    $date[2025][6][24]["epistle"] = "Romans 13:11-14,14:1-4";
    $date[2025][6][24]["gospel"] = "Luke 1:1-25,57-68,76,80";

    $date[2025][6][25]["minor"] = "Martyr Febronia";
    $date[2025][6][25]["epistle"] = "Romans 8:2-13";
    $date[2025][6][25]["gospel"] = "Matthew 10:16-22";

    $date[2025][6][26]["minor"] = "Father David of Thessalonica";
    $date[2025][6][26]["epistle"] = "Romans 8:22-28";
    $date[2025][6][26]["gospel"] = "Matthew 10:23-31";

    $date[2025][6][27]["minor"] = "Father Samson the Hosteler";
    $date[2025][6][27]["epistle"] = "Romans 9:6-19";
    $date[2025][6][27]["gospel"] = "Matthew 10:32-42,11:1";

    $date[2025][6][28]["minor"] = "Transfer of the Remains of the Holy Physicians Cyrus and John";
    $date[2025][6][28]["epistle"] = "Romans 3:28-31,4:1-3";
    $date[2025][6][28]["gospel"] = "Matthew 7:24-29,8:1-4";

    $date[2025][6][29]["major"] = "Third Sunday After Pentecost";
    $date[2025][6][29]["minor"] = "Apostles Peter and Paul";
    $date[2025][6][29]["tone"] = "Tone 2";
    $date[2025][6][29]["orthros"] = "Mark 16:9-20 (3)";
    $date[2025][6][29]["epistle"] = "2 Corinthians 11:21-33,12:1-9";
    $date[2025][6][29]["gospel"] = "Matthew 16:13-19";

    $date[2025][6][30]["major"] = "Synaxis of the Twelve Apostles";
    $date[2025][6][30]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][6][30]["gospel"] = "Matthew 9:36-38,10:1-8";

    $date[2025][7][1]["major"] = "Wonderworkers Cosmas and Damian";
    $date[2025][7][1]["epistle"] = "1 Corinthians 12:27-31,13:1-8";
    $date[2025][7][1]["gospel"] = "Matthew 10:1,5-8";

    $date[2025][7][2]["major"] = "Deposition of the Mantle of the Mother of God, at Blachernae";
    $date[2025][7][2]["epistle"] = "Hebrews 9:1-7";
    $date[2025][7][2]["gospel"] = "Luke 1:39-49,56";

    $date[2025][7][3]["minor"] = "Martyr Hyacinth and Father Anatolios, Patriarch of Constantinople";
    $date[2025][7][3]["epistle"] = "Romans 11:13-24";
    $date[2025][7][3]["gospel"] = "Matthew 11:27-30";

    $date[2025][7][4]["minor"] = "Father Andrew of Jerusalem";
    $date[2025][7][4]["epistle"] = "Romans 11:25-36";
    $date[2025][7][4]["gospel"] = "Matthew 12:1-8";

    $date[2025][7][5]["minor"] = "Father Athanasius of Athos - Lampados and Martha";
    $date[2025][7][5]["epistle"] = "Romans 6:11-17";
    $date[2025][7][5]["gospel"] = "Matthew 8:14-23";

    $date[2025][7][6]["major"] = "Fourth Sunday After Pentecost";
    $date[2025][7][6]["minor"] = "Father Sisoe the Great";
    $date[2025][7][6]["tone"] = "Tone 3";
    $date[2025][7][6]["orthros"] = "Luke 24:1-12 (4)";
    $date[2025][7][6]["epistle"] = "Romans 6:18-23";
    $date[2025][7][6]["gospel"] = "Matthew 8:5-13";

    $date[2025][7][7]["minor"] = "Fathers Thomas of Maleum, Acacius - Martyr Kyriaca";
    $date[2025][7][7]["epistle"] = "Romans 12:4-5,15-21";
    $date[2025][7][7]["gospel"] = "Matthew 12:9-13";

    $date[2025][7][8]["minor"] = "Great-martyr Procopius";
    $date[2025][7][8]["epistle"] = "Romans 14:9-18";
    $date[2025][7][8]["gospel"] = "Matthew 12:14-16,22-30";

    $date[2025][7][9]["minor"] = "Hieromartyr Pancratius, Bishop of Taormina in Sicily";
    $date[2025][7][9]["epistle"] = "Romans 15:7-16";
    $date[2025][7][9]["gospel"] = "Matthew 12:38-45";

    $date[2025][7][10]["minor"] = "Forty-five Martyrs of Nicopolis in Armenia";
    $date[2025][7][10]["epistle"] = "Romans 15:17-29";
    $date[2025][7][10]["gospel"] = "Matthew 12:46-50,13:1-3";

    $date[2025][7][11]["minor"] = "Great-martyr Euphemia";
    $date[2025][7][11]["epistle"] = "2 Corinthians 6:1-10";
    $date[2025][7][11]["gospel"] = "Luke 7:36-50";

    $date[2025][7][12]["minor"] = "Martyrs Proclus and Hilarion";
    $date[2025][7][12]["epistle"] = "Romans 8:14-21";
    $date[2025][7][12]["gospel"] = "Matthew 9:9-13";

    $date[2025][7][13]["major"] = "Sunday of the Fathers of the First Six Ecumenical Councils";
    $date[2025][7][13]["minor"] = "Archangel Gabriel - Father Stephen the Sabaite";
    $date[2025][7][13]["tone"] = "Tone 4";
    $date[2025][7][13]["orthros"] = "Luke 24:12-35 (5)";
    $date[2025][7][13]["epistle"] = "Titus 3:8-15";
    $date[2025][7][13]["gospel"] = "Matthew 5:14-19";

    $date[2025][7][14]["minor"] = "Apostle Aquila and Joseph the Confessor";
    $date[2025][7][14]["epistle"] = "Romans 16:17-24";
    $date[2025][7][14]["gospel"] = "Matthew 13:10-23";

    $date[2025][7][15]["minor"] = "Martyrs Cyricus and His Mother Julitta";
    $date[2025][7][15]["epistle"] = "1 Corinthians 1:1-9";
    $date[2025][7][15]["gospel"] = "Matthew 13:24-30";

    $date[2025][7][16]["minor"] = "Hieromartyr Athenogenes and His Ten Disciples";
    $date[2025][7][16]["epistle"] = "1 Corinthians 2:9-16,3:1-8";
    $date[2025][7][16]["gospel"] = "Matthew 13:31-36";

    $date[2025][7][17]["minor"] = "Great Martyr Marina";
    $date[2025][7][17]["epistle"] = "Galatians 3:23-29,4:1-5";
    $date[2025][7][17]["gospel"] = "Mark 5:24-34";

    $date[2025][7][18]["minor"] = "Martyr Emilian";
    $date[2025][7][18]["epistle"] = "1 Corinthians 4:5-8";
    $date[2025][7][18]["gospel"] = "Matthew 13:44-54";

    $date[2025][7][19]["minor"] = "Mother Macrina, Sister of Basil the Great - Father Dios";
    $date[2025][7][19]["epistle"] = "Romans 9:1-5";
    $date[2025][7][19]["gospel"] = "Matthew 9:18-26";

    $date[2025][7][20]["major"] = "Sixth Sunday After Pentecost";
    $date[2025][7][20]["minor"] = "Prophet Elias the Thesbite";
    $date[2025][7][20]["tone"] = "Tone 5";
    $date[2025][7][20]["orthros"] = "Luke 24:36-53 (6)";
    $date[2025][7][20]["epistle"] = "James 5:10-20";
    $date[2025][7][20]["gospel"] = "Matthew 9:1-8";

    $date[2025][7][21]["minor"] = "Fathers Simeon, the Fool for Christ and His Companion John";
    $date[2025][7][21]["epistle"] = "1 Corinthians 5:9-13,6:1-11";
    $date[2025][7][21]["gospel"] = "Matthew 13:54-58";

    $date[2025][7][22]["minor"] = "Perfume-bearing Woman Mary Magdalen";
    $date[2025][7][22]["epistle"] = "1 Corinthians 9:2-12";
    $date[2025][7][22]["gospel"] = "Luke 8:1-3";

    $date[2025][7][23]["minor"] = "Transfer of the Remains of Hieromartyr Phocas -  prophet Ezechiel";
    $date[2025][7][23]["epistle"] = "1 Corinthians 7:12-24";
    $date[2025][7][23]["gospel"] = "Matthew 14:35-36,15:1-11";

    $date[2025][7][24]["minor"] = "Great-martyr Christina";
    $date[2025][7][24]["epistle"] = "1 Corinthians 7:24-35";
    $date[2025][7][24]["gospel"] = "Matthew 15:12-21";

    $date[2025][7][25]["major"] = "Dormition of St. Ann";
    $date[2025][7][25]["epistle"] = "Galatians 4:22-27";
    $date[2025][7][25]["gospel"] = "Luke 8:16-21";

    $date[2025][7][26]["minor"] = "Hieromartyr Hermolaus and His Two Companions - Martyr Parasceva";
    $date[2025][7][26]["epistle"] = "Romans 12:1-3";
    $date[2025][7][26]["gospel"] = "Matthew 10:37-42,11:1";

    $date[2025][7][27]["major"] = "Seventh Sunday After Pentecost";
    $date[2025][7][27]["minor"] = "Great-martyr Panteleimon the Physician";
    $date[2025][7][27]["tone"] = "Tone 6";
    $date[2025][7][27]["orthros"] = "John 20:1-10 (7)";
    $date[2025][7][27]["epistle"] = "2 Timothy 2:1-10";
    $date[2025][7][27]["gospel"] = "Matthew 9:27-35";

    $date[2025][7][28]["minor"] = "Deacons Prochor, Nicanor, Timon and Parmenas";
    $date[2025][7][28]["epistle"] = "1 Corinthians 9:13-18";
    $date[2025][7][28]["gospel"] = "Matthew 16:1-6";

    $date[2025][7][29]["minor"] = "Martyrs Callinicus and Theodota";
    $date[2025][7][29]["epistle"] = "1 Corinthians 10:5-12";
    $date[2025][7][29]["gospel"] = "Matthew 16:6-12";

    $date[2025][7][30]["minor"] = "Apostles Silas and Silvan and Their Companions";
    $date[2025][7][30]["epistle"] = "1 Corinthians 10:12-22";
    $date[2025][7][30]["gospel"] = "Matthew 16:20-24";

    $date[2025][7][31]["minor"] = "Holy and Just Eudocimos - Vigil of the Procession of the Cross";
    $date[2025][7][31]["epistle"] = "1 Corinthians 10:28-33,11:1-8";
    $date[2025][7][31]["gospel"] = "Matthew 16:24-28";

    $date[2025][8][1]["major"] = "Procession of the Life-giving Cross - Begining of the Theotokos' Fast";
    $date[2025][8][1]["minor"] = "Seven Macchabees, Their Mother Salome and  the Elder Eleazar";
    $date[2025][8][1]["epistle"] = "Hebrews 11:33-40,12:1-2";
    $date[2025][8][1]["gospel"] = "Matthew 10:16-22";

    $date[2025][8][2]["minor"] = "Transfer of the Remains of the Holy Protomartyr the Archdeacon Stephen";
    $date[2025][8][2]["epistle"] = "Romans 13:1-10";
    $date[2025][8][2]["gospel"] = "Matthew 12:30-37";

    $date[2025][8][3]["major"] = "Eighth Sunday After Pentecost";
    $date[2025][8][3]["minor"] = "Fathers Isaac, Dalmatus and Faustus";
    $date[2025][8][3]["tone"] = "Tone 7";
    $date[2025][8][3]["orthros"] = "John 20:11-18 (8)";
    $date[2025][8][3]["epistle"] = "1 Corinthians 1:10-17";
    $date[2025][8][3]["gospel"] = "Matthew 14:14-22";

    $date[2025][8][4]["minor"] = "Seven Holy Youths of Ephesus and of Martyr Eudocia";
    $date[2025][8][4]["epistle"] = "1 Corinthians 11:31-34,12:1-6";
    $date[2025][8][4]["gospel"] = "Matthew 18:1-11";

    $date[2025][8][5]["minor"] = "Preparation of the Transfiguration - Martyr Eusignius";
    $date[2025][8][5]["epistle"] = "1 Corinthians 12:12-26";
    $date[2025][8][5]["gospel"] = "Matthew 18:18-22,19:1-2,13-15";

    $date[2025][8][6]["major"] = "Transfiguration of our Lord";
    $date[2025][8][6]["orthros"] = "Luke 9:28-36";
    $date[2025][8][6]["epistle"] = "2 Peter 1:10-19";
    $date[2025][8][6]["gospel"] = "Matthew 17:1-9";

    $date[2025][8][7]["minor"] = "Martyr Dometios";
    $date[2025][8][7]["epistle"] = "1 Corinthians 14:6-19";
    $date[2025][8][7]["gospel"] = "Matthew 20:17-28";

    $date[2025][8][8]["minor"] = "Confessor Emilian, Bishop of Cyrica";
    $date[2025][8][8]["epistle"] = "1 Corinthians 14:26-40";
    $date[2025][8][8]["gospel"] = "Matthew 21:12-14,17-20";

    $date[2025][8][9]["minor"] = "Apostle Matthias";
    $date[2025][8][9]["epistle"] = "Romans 14:6-9";
    $date[2025][8][9]["gospel"] = "Matthew 15:32-39";

    $date[2025][8][10]["major"] = "Ninth Sunday After Pentecost";
    $date[2025][8][10]["minor"] = "Martyr Archdeacon Lawrence";
    $date[2025][8][10]["tone"] = "Tone 8";
    $date[2025][8][10]["orthros"] = "John 20:19-31 (9)";
    $date[2025][8][10]["epistle"] = "1 Corinthians 3:9-17";
    $date[2025][8][10]["gospel"] = "Matthew 14:22-34";

    $date[2025][8][11]["minor"] = "Martyr Euplus the Deacon";
    $date[2025][8][11]["epistle"] = "1 Corinthians 15:12-19";
    $date[2025][8][11]["gospel"] = "Matthew 21:18-22";

    $date[2025][8][12]["minor"] = "Martyrs Photios and Anicetos and Maximos the Confessor";
    $date[2025][8][12]["epistle"] = "1 Corinthians 15:29-38";
    $date[2025][8][12]["gospel"] = "Matthew 21:23-27";

    $date[2025][8][13]["major"] = "Leave-taking of the Transfiguration";
    $date[2025][8][13]["epistle"] = "1 Corinthians 16:4-12";
    $date[2025][8][13]["gospel"] = "Matthew 21:28-32";

    $date[2025][8][14]["minor"] = "Vigil of the Dormition -  prophet Micah";
    $date[2025][8][14]["epistle"] = "2 Corinthians 1:1-7";
    $date[2025][8][14]["gospel"] = "Matthew 21:43-46";

    $date[2025][8][15]["major"] = "Dormition of the Mother of God";
    $date[2025][8][15]["orthros"] = "Luke 1:39-49,56";
    $date[2025][8][15]["epistle"] = "Philippians 2:5-11";
    $date[2025][8][15]["gospel"] = "Luke 10:38-42,11:27-28";

    $date[2025][8][16]["minor"] = "Martyr Diomedes";
    $date[2025][8][16]["epistle"] = "1 Timothy 3:13-16,4:1-5";
    $date[2025][8][16]["gospel"] = "Luke 9:51-56,10:22-24,13:22";

    $date[2025][8][17]["major"] = "Tenth Sunday After Pentecost";
    $date[2025][8][17]["minor"] = "Martyr Myron";
    $date[2025][8][17]["tone"] = "Tone 1";
    $date[2025][8][17]["orthros"] = "John 21:1-14 (10)";
    $date[2025][8][17]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][8][17]["gospel"] = "Matthew 17:14-23";

    $date[2025][8][18]["minor"] = "Martyrs Florus and Laurus";
    $date[2025][8][18]["epistle"] = "2 Corinthians 2:3-15";
    $date[2025][8][18]["gospel"] = "Matthew 23:13-22";

    $date[2025][8][19]["minor"] = "Martyrs Andrew the Centurion and His Companions";
    $date[2025][8][19]["epistle"] = "2 Corinthians 2:14-17,3:1-3";
    $date[2025][8][19]["gospel"] = "Matthew 23:23-28";

    $date[2025][8][20]["minor"] = "Prophet Samuel";
    $date[2025][8][20]["epistle"] = "2 Corinthians 3:4-11";
    $date[2025][8][20]["gospel"] = "Matthew 23:29-39";

    $date[2025][8][21]["minor"] = "Apostle Thaddeus - Martyr Bassa and Her Children";
    $date[2025][8][21]["epistle"] = "2 Corinthians 4:1-12";
    $date[2025][8][21]["gospel"] = "Matthew 24:13-28";

    $date[2025][8][22]["minor"] = "Martyrs Agathonicos and His Companions";
    $date[2025][8][22]["epistle"] = "2 Corinthians 4:13-18";
    $date[2025][8][22]["gospel"] = "Matthew 24:27-33,42-51";

    $date[2025][8][23]["major"] = "Leave-taking of the Dormition";
    $date[2025][8][23]["minor"] = "Martyr Luppus and Hieromartyr Irenaeus";
    $date[2025][8][23]["epistle"] = "1 Corinthians 1:3-9";
    $date[2025][8][23]["gospel"] = "Matthew 19:3-12";

    $date[2025][8][24]["major"] = "Eleventh Sunday After Pentecost";
    $date[2025][8][24]["minor"] = "Hieromartyr Eutyches, Disciple of Saint John the Theologian";
    $date[2025][8][24]["tone"] = "Tone 2";
    $date[2025][8][24]["orthros"] = "John 21:14-25 (11)";
    $date[2025][8][24]["epistle"] = "1 Corinthians 9:2-12";
    $date[2025][8][24]["gospel"] = "Matthew 18:23-35";

    $date[2025][8][25]["minor"] = "Transfer of the Remains of the Apostle Bartholomew -  apostle Titus";
    $date[2025][8][25]["epistle"] = "2 Corinthians 5:10-15";
    $date[2025][8][25]["gospel"] = "Mark 1:9-15";

    $date[2025][8][26]["minor"] = "Martyrs Adrian and His Wife Natalia. Blessed Mary Bawardy";
    $date[2025][8][26]["epistle"] = "2 Corinthians 5:15-21";
    $date[2025][8][26]["gospel"] = "Mark 1:16-22";

    $date[2025][8][27]["minor"] = "Father Poemen and Martyr Phanurios";
    $date[2025][8][27]["epistle"] = "2 Corinthians 6:11-16";
    $date[2025][8][27]["gospel"] = "Mark 1:23-28";

    $date[2025][8][28]["minor"] = "Fathers Moses the Abyssinian and Augustine, Bishop of Hippo";
    $date[2025][8][28]["epistle"] = "2 Corinthians 7:1-10";
    $date[2025][8][28]["gospel"] = "Mark 1:29-35";

    $date[2025][8][29]["major"] = "Beheading of the Forerunner";
    $date[2025][8][29]["orthros"] = "Matthew 14:1-13";
    $date[2025][8][29]["epistle"] = "Acts 13:25-33";
    $date[2025][8][29]["gospel"] = "Mark 6:14-30";

    $date[2025][8][30]["minor"] = "Fathers Alexander, John and Paul the Latter, Archbishops of Constantinople";
    $date[2025][8][30]["epistle"] = "1 Corinthians 1:26-31,2:1-5";
    $date[2025][8][30]["gospel"] = "Matthew 20:29-34";

    $date[2025][8][31]["major"] = "Twelfth Sunday After Pentecost";
    $date[2025][8][31]["tone"] = "Tone 3";
    $date[2025][8][31]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][8][31]["epistle"] = "Hebrews 9:1-7";
    $date[2025][8][31]["gospel"] = "Matthew 19:16-26";

    $date[2025][9][1]["major"] = "Church's New Year";
    $date[2025][9][1]["minor"] = "Father Simeon the Stylite - Synaxis of the Mother of God";
    $date[2025][9][1]["orthros"] = "Luke 6:17-23";
    $date[2025][9][1]["epistle"] = "1 Timothy 2:1-7";
    $date[2025][9][1]["gospel"] = "Luke 4:16-22";

    $date[2025][9][2]["minor"] = "Martyr Mammas - John the Faster, Patriarch of Constantinople";
    $date[2025][9][2]["epistle"] = "2 Corinthians 8:16-24,9:1-5";
    $date[2025][9][2]["gospel"] = "Mark 3:13-19";

    $date[2025][9][3]["minor"] = "Hieromartyr Anthimos, Bishop of Nicomedia - Father Theoctistos";
    $date[2025][9][3]["epistle"] = "2 Corinthians 9:12-15,10:1-7";
    $date[2025][9][3]["gospel"] = "Mark 3:20-27";

    $date[2025][9][4]["minor"] = "Hieromartyr Babylas Bishop of Antioch - Prophet Moses";
    $date[2025][9][4]["epistle"] = "2 Corinthians 10:7-18";
    $date[2025][9][4]["gospel"] = "Mark 3:28-35";

    $date[2025][9][5]["minor"] = "Prophet Zachariah, Father of the Forerunner";
    $date[2025][9][5]["epistle"] = "2 Corinthians 11:5-21";
    $date[2025][9][5]["gospel"] = "Mark 4:1-9";

    $date[2025][9][6]["major"] = "The Miracle of Archangel Michael at Colossae";
    $date[2025][9][6]["epistle"] = "Hebrews 2:2-10";
    $date[2025][9][6]["gospel"] = "Luke 10:16-21";

    $date[2025][9][7]["major"] = "Sunday Before the Holy Cross";
    $date[2025][9][7]["minor"] = "Forefeast of the Nativity of the Mother of God - Martyr Sozon";
    $date[2025][9][7]["tone"] = "Tone 4";
    $date[2025][9][7]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][9][7]["epistle"] = "Galatians 6:11-18";
    $date[2025][9][7]["gospel"] = "John 3:13-17";

    $date[2025][9][8]["major"] = "Nativity of the Mother of God";
    $date[2025][9][8]["orthros"] = "Luke 1:39-49,56";
    $date[2025][9][8]["epistle"] = "Philippians 2:5-11";
    $date[2025][9][8]["gospel"] = "Luke 10:38-42,11:27-28";

    $date[2025][9][9]["major"] = "Ancestors of Christ Joachim and Ann";
    $date[2025][9][9]["minor"] = "Martyr Severian";
    $date[2025][9][9]["epistle"] = "Galatians 4:22-27";
    $date[2025][9][9]["gospel"] = "Luke 8:16-21";

    $date[2025][9][10]["minor"] = "Martyrs Menodora, Metrodora and Nymphodora";
    $date[2025][9][10]["epistle"] = "2 Corinthians 13:3-13";
    $date[2025][9][10]["gospel"] = "Mark 4:35-41";

    $date[2025][9][11]["minor"] = "Mother Theodora of Alexandria";
    $date[2025][9][11]["epistle"] = "Galatians 1:1-3,20-24,2:1-5";
    $date[2025][9][11]["gospel"] = "Mark 5:1-20";

    $date[2025][9][12]["major"] = "Leave-taking of the Nativity of Mary";
    $date[2025][9][12]["minor"] = "Martyr Autonomus";
    $date[2025][9][12]["epistle"] = "Galatians 2:6-10";
    $date[2025][9][12]["gospel"] = "Mark 5:22-24,35-43,6:1";

    $date[2025][9][13]["major"] = "Saturday Before the Holy Cross";
    $date[2025][9][13]["minor"] = "Dedication of the Basilica of the Resurrection";
    $date[2025][9][13]["epistle"] = "1 Corinthians 2:6-9";
    $date[2025][9][13]["gospel"] = "John 12:25-36";

    $date[2025][9][14]["major"] = "Exaltation of the Cross";
    $date[2025][9][14]["tone"] = "Tone 5";
    $date[2025][9][14]["orthros"] = "John 12:28-36";
    $date[2025][9][14]["epistle"] = "1 Corinthians 1:18-24";
    $date[2025][9][14]["gospel"] = "John 19:6-11,13-20,25-35";

    $date[2025][9][15]["minor"] = "Martyr Nicetas";
    $date[2025][9][15]["epistle"] = "Galatians 2:11-16";
    $date[2025][9][15]["gospel"] = "Mark 5:24-34";

    $date[2025][9][16]["minor"] = "Great-martyr Euphemia";
    $date[2025][9][16]["epistle"] = "2 Corinthians 6:1-10";
    $date[2025][9][16]["gospel"] = "Luke 7:36-50";

    $date[2025][9][17]["minor"] = "Martyrs Sophia and of Her Daughters, Faith, Hope and Charity";
    $date[2025][9][17]["epistle"] = "Galatians 3:15-22";
    $date[2025][9][17]["gospel"] = "Mark 6:7-13";

    $date[2025][9][18]["minor"] = "Father Eumenius, Bishop of Gortyna in Crete";
    $date[2025][9][18]["epistle"] = "Galatians 3:23-29,4:1-5";
    $date[2025][9][18]["gospel"] = "Mark 6:30-45";

    $date[2025][9][19]["minor"] = "Martyrs Trophimus, Sabbatius and Dorymedes";
    $date[2025][9][19]["epistle"] = "Galatians 4:8-21";
    $date[2025][9][19]["gospel"] = "Mark 6:45-53";

    $date[2025][9][20]["major"] = "Saturday After the Holy Cross";
    $date[2025][9][20]["minor"] = "Great-martyr Eustathius, His Wife Theopista and Their Children Agapius and Theopista";
    $date[2025][9][20]["epistle"] = "1 Corinthians 1:26-31,2:1,5";
    $date[2025][9][20]["gospel"] = "John 8:21-30";

    $date[2025][9][21]["major"] = "Sunday After the Holy Cross";
    $date[2025][9][21]["minor"] = "Leave-taking of the Exaltation of the Cross";
    $date[2025][9][21]["tone"] = "Tone 6";
    $date[2025][9][21]["orthros"] = "Luke 24:1-12 (4)";
    $date[2025][9][21]["epistle"] = "Galatians 2:16-20";
    $date[2025][9][21]["gospel"] = "Mark 8:34-38,9:1";

    $date[2025][9][22]["minor"] = "Hieromartyr Phocas";
    $date[2025][9][22]["epistle"] = "Galatians 4:28-31,5:1-10";
    $date[2025][9][22]["gospel"] = "Luke 3:19-22";

    $date[2025][9][23]["major"] = "Conception of the Forerunner";
    $date[2025][9][23]["epistle"] = "Galatians 4:22-27";
    $date[2025][9][23]["gospel"] = "Luke 1:5-25";

    $date[2025][9][24]["minor"] = "Protomartyr Thecla";
    $date[2025][9][24]["epistle"] = "Galatians 6:2-10";
    $date[2025][9][24]["gospel"] = "Luke 4:1-15";

    $date[2025][9][25]["minor"] = "Mother Euphrosyne";
    $date[2025][9][25]["epistle"] = "Ephesians 1:1-9";
    $date[2025][9][25]["gospel"] = "Luke 4:16-22";

    $date[2025][9][26]["major"] = "Repose of St. John, Apostle and Theologian";
    $date[2025][9][26]["orthros"] = "John 21:14-25 (11)";
    $date[2025][9][26]["epistle"] = "1 John 4:12-19";
    $date[2025][9][26]["gospel"] = "John 19:25-27,21:24-25";

    $date[2025][9][27]["minor"] = "Martyrs Callistratos and His Companions";
    $date[2025][9][27]["epistle"] = "1 Corinthians 10:23-28";
    $date[2025][9][27]["gospel"] = "Luke 4:31-36";

    $date[2025][9][28]["major"] = "First Sunday After the Holy Cross";
    $date[2025][9][28]["minor"] = "Father Chariton the Confessor";
    $date[2025][9][28]["tone"] = "Tone 7";
    $date[2025][9][28]["orthros"] = "Luke 24:12-35 (5)";
    $date[2025][9][28]["epistle"] = "2 Corinthians 6:1-10";
    $date[2025][9][28]["gospel"] = "Luke 5:1-11";

    $date[2025][9][29]["minor"] = "Father Cyriakos the Anchorite";
    $date[2025][9][29]["epistle"] = "Ephesians 1:22-23,2:1-3";
    $date[2025][9][29]["gospel"] = "Luke 4:38-44";

    $date[2025][9][30]["minor"] = "Hieromartyr Gregory, Bishop of Armenia";
    $date[2025][9][30]["epistle"] = "Ephesians 2:19-22,3:1-7";
    $date[2025][9][30]["gospel"] = "Luke 5:12-16";

    $date[2025][10][1]["major"] = "Protection of the Mother of God";
    $date[2025][10][1]["minor"] = "Apostle Ananias - Father Romanos the Melodist";
    $date[2025][10][1]["epistle"] = "Hebrews 9:1-7";
    $date[2025][10][1]["gospel"] = "Luke 10:38-42,11:27-28";

    $date[2025][10][2]["minor"] = "Hieromartyr Cyprian - Martyr Justina";
    $date[2025][10][2]["epistle"] = "Ephesians 4:14-17";
    $date[2025][10][2]["gospel"] = "Luke 6:12-19";

    $date[2025][10][3]["minor"] = "Hieromartyr Dionysios";
    $date[2025][10][3]["epistle"] = "Ephesians 4:17-25";
    $date[2025][10][3]["gospel"] = "Luke 6:17-23";

    $date[2025][10][4]["minor"] = "Hieromartyr Hierotheos, Bishop of Athens";
    $date[2025][10][4]["epistle"] = "1 Corinthians 14:20-25";
    $date[2025][10][4]["gospel"] = "Luke 5:17-26";

    $date[2025][10][5]["major"] = "Second Sunday After the Holy Cross";
    $date[2025][10][5]["minor"] = "Martyr Charitina";
    $date[2025][10][5]["tone"] = "Tone 8";
    $date[2025][10][5]["orthros"] = "Luke 24:36-53 (6)";
    $date[2025][10][5]["epistle"] = "2 Corinthians 6:16-18,7:1";
    $date[2025][10][5]["gospel"] = "Luke 6:31-36";

    $date[2025][10][6]["major"] = "Apostle Thomas";
    $date[2025][10][6]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][10][6]["gospel"] = "John 20:19-31";

    $date[2025][10][7]["minor"] = "Martyrs Sergius and Bacchus";
    $date[2025][10][7]["epistle"] = "Ephesians 5:20-25";
    $date[2025][10][7]["gospel"] = "Luke 6:37-45";

    $date[2025][10][8]["minor"] = "Mother Pelagia";
    $date[2025][10][8]["epistle"] = "Ephesians 5:25-33";
    $date[2025][10][8]["gospel"] = "Luke 6:46-49,7:1";

    $date[2025][10][9]["major"] = "Apostle James, Son of Alpheus";
    $date[2025][10][9]["minor"] = "Father Andronikos and His Wife Athanasia";
    $date[2025][10][9]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][10][9]["gospel"] = "Matthew 9:36-38,10:1-8";

    $date[2025][10][10]["minor"] = "Martyrs Eulampius and Eulampia";
    $date[2025][10][10]["epistle"] = "Ephesians 6:18-24";
    $date[2025][10][10]["gospel"] = "Luke 7:31-35";

    $date[2025][10][11]["minor"] = "Apostle Philip - Father Theophane, Bishop of Nicea";
    $date[2025][10][11]["epistle"] = "1 Corinthians 15:39-45";
    $date[2025][10][11]["gospel"] = "Luke 5:27-32";

    $date[2025][10][12]["major"] = "Fathers of the Second Council of Nicea";
    $date[2025][10][12]["tone"] = "Tone 1";
    $date[2025][10][12]["orthros"] = "John 20:1-10 (7)";
    $date[2025][10][12]["epistle"] = "Titus 3:8-15";
    $date[2025][10][12]["gospel"] = "Luke 8:5-15";

    $date[2025][10][13]["minor"] = "Martyrs Carpos, Papylas and Agathonicos";
    $date[2025][10][13]["epistle"] = "Philippians 1:1-7";
    $date[2025][10][13]["gospel"] = "Luke 7:36-50";

    $date[2025][10][14]["minor"] = "Martyrs Nazarius, Gervasius, Protasius and Celsus - Father Cosmas the Poet, Bishop of Maiuma";
    $date[2025][10][14]["epistle"] = "Philippians 1:8-14";
    $date[2025][10][14]["gospel"] = "Luke 8:1-3";

    $date[2025][10][15]["minor"] = "Martyr Lucian, Priest of Antioch";
    $date[2025][10][15]["epistle"] = "Philippians 1:12-19";
    $date[2025][10][15]["gospel"] = "Luke 8:22-25";

    $date[2025][10][16]["minor"] = "Martyr Longinus the Centurion";
    $date[2025][10][16]["epistle"] = "Philippians 1:20-27";
    $date[2025][10][16]["gospel"] = "Luke 9:7-11";

    $date[2025][10][17]["minor"] = "Prophet Hosea - Martyr Andrew of Crete";
    $date[2025][10][17]["epistle"] = "Philippians 1:27-30,2:1-4";
    $date[2025][10][17]["gospel"] = "Luke 9:12-18";

    $date[2025][10][18]["major"] = "Apostle Luke the Evangelist";
    $date[2025][10][18]["epistle"] = "Colossians 4:5-11,14-18";
    $date[2025][10][18]["gospel"] = "Luke 10:16-21";

    $date[2025][10][19]["major"] = "Third Sunday After the Holy Cross";
    $date[2025][10][19]["minor"] = "Prophet Joel - Martyr Varus";
    $date[2025][10][19]["tone"] = "Tone 2";
    $date[2025][10][19]["orthros"] = "John 20:11-18 (8)";
    $date[2025][10][19]["epistle"] = "2 Corinthians 11:31-33,12:1-9";
    $date[2025][10][19]["gospel"] = "Luke 7:11-16";

    $date[2025][10][20]["minor"] = "Great-martyr Artemius";
    $date[2025][10][20]["epistle"] = "Philippians 2:12-16";
    $date[2025][10][20]["gospel"] = "Luke 9:18-22";

    $date[2025][10][21]["minor"] = "Father Hilarion";
    $date[2025][10][21]["epistle"] = "Philippians 2:16-23";
    $date[2025][10][21]["gospel"] = "Luke 9:23-27";

    $date[2025][10][22]["minor"] = "Abercius Bishop of Hieropolis - Seven Children Martyred at Ephesus";
    $date[2025][10][22]["epistle"] = "Philippians 2:24-30";
    $date[2025][10][22]["gospel"] = "Luke 9:44-50";

    $date[2025][10][23]["major"] = "Hieromartyr James,  first Bishop of Jerusalem";
    $date[2025][10][23]["epistle"] = "Galatians 1:11-19";
    $date[2025][10][23]["gospel"] = "Luke 9:49-56";

    $date[2025][10][24]["minor"] = "Great-martyr Arethas and His Companions";
    $date[2025][10][24]["epistle"] = "Philippians 3:8-19";
    $date[2025][10][24]["gospel"] = "Luke 10:1-15";

    $date[2025][10][25]["minor"] = "Martyrs Marcian and Martyrius";
    $date[2025][10][25]["epistle"] = "2 Corinthians 1:8-11";
    $date[2025][10][25]["gospel"] = "Luke 7:1-10";

    $date[2025][10][26]["major"] = "Sixth Sunday After the Holy Cross";
    $date[2025][10][26]["minor"] = "Great-martyr Demetrios";
    $date[2025][10][26]["tone"] = "Tone 3";
    $date[2025][10][26]["orthros"] = "John 20:19-31 (9)";
    $date[2025][10][26]["epistle"] = "2 Timothy 2:1-10";
    $date[2025][10][26]["gospel"] = "Luke 8:27-39";

    $date[2025][10][27]["minor"] = "Martyr Nestor";
    $date[2025][10][27]["epistle"] = "Philippians 4:10-23";
    $date[2025][10][27]["gospel"] = "Luke 10:22-24";

    $date[2025][10][28]["minor"] = "Martyrs Terence and Neonila - Father Stephen the Sabaite";
    $date[2025][10][28]["epistle"] = "Colossians 1:1-11";
    $date[2025][10][28]["gospel"] = "Luke 11:1-10";

    $date[2025][10][29]["minor"] = "Martyr Anastasia - Father Abramios";
    $date[2025][10][29]["epistle"] = "Colossians 1:18-23";
    $date[2025][10][29]["gospel"] = "Luke 11:9-13";

    $date[2025][10][30]["minor"] = "Martyr Zenobius and of His Sister Zenobia";
    $date[2025][10][30]["epistle"] = "Colossians 1:24-29,2:1";
    $date[2025][10][30]["gospel"] = "Luke 11:14-23";

    $date[2025][10][31]["minor"] = "Apostles Stachys, Apelles, Amplias, Urban, Aristobulus and Marcissus - Martyr Epimakius";
    $date[2025][10][31]["epistle"] = "Colossians 2:1-7";
    $date[2025][10][31]["gospel"] = "Luke 11:23-26";

    $date[2025][11][1]["major"] = "Martyrs, Wonderworkers and Physicians Cosmas and Damian";
    $date[2025][11][1]["epistle"] = "1 Corinthians 12:27-31,13:1-8";
    $date[2025][11][1]["gospel"] = "Matthew 10:1,5-8";

    $date[2025][11][2]["major"] = "Fifth Sunday After the Holy Cross";
    $date[2025][11][2]["minor"] = "Martyrs Akindinus, Pegasius, Aphtonius, Elpidephor and Anempodisius";
    $date[2025][11][2]["tone"] = "Tone 4";
    $date[2025][11][2]["orthros"] = "John 21:1-14 (10)";
    $date[2025][11][2]["epistle"] = "Galatians 2:16-20";
    $date[2025][11][2]["gospel"] = "Luke 16:19-31";

    $date[2025][11][3]["minor"] = "Martyrs Acepsimas, Joseph and Aeithalas - Dedication of the Church of the Great-martyr George";
    $date[2025][11][3]["epistle"] = "Colossians 2:13-20";
    $date[2025][11][3]["gospel"] = "Luke 11:29-33";

    $date[2025][11][4]["minor"] = "Father Joannicios the Great - Hieromartyr Nicander, Bishop of Myra - Hermeus, a Priest";
    $date[2025][11][4]["epistle"] = "Colossians 2:20-23,3:1-3";
    $date[2025][11][4]["gospel"] = "Luke 11:34-41";

    $date[2025][11][5]["minor"] = "Martyrs Galaction and His Wife Episteme";
    $date[2025][11][5]["epistle"] = "Colossians 3:17-25,4:1";
    $date[2025][11][5]["gospel"] = "Luke 11:42-46";

    $date[2025][11][6]["minor"] = "Father Paul, Archbishop of Constantinople, Confessor";
    $date[2025][11][6]["epistle"] = "Colossians 4:2-9";
    $date[2025][11][6]["gospel"] = "Luke 11:47-54,12:1";

    $date[2025][11][7]["minor"] = "Thirty-two Martyrs of Melitene -father Lazarus the Wonderworker";
    $date[2025][11][7]["epistle"] = "Colossians 4:10-18";
    $date[2025][11][7]["gospel"] = "Luke 12:2-11";

    $date[2025][11][8]["major"] = "Synaxis of the Archangels Michael and Gabriel and All the Heavenly Powers";
    $date[2025][11][8]["orthros"] = "Matthew 18:10-20";
    $date[2025][11][8]["epistle"] = "Hebrews 2:2-10";
    $date[2025][11][8]["gospel"] = "Luke 10:16-21";

    $date[2025][11][9]["major"] = "Seventh Sunday After the Holy Cross";
    $date[2025][11][9]["minor"] = "Martyrs Onesiphorus and Porphyry - Mother Matrona";
    $date[2025][11][9]["tone"] = "Tone 5";
    $date[2025][11][9]["orthros"] = "John 21:14-25 (11)";
    $date[2025][11][9]["epistle"] = "Galatians 6:11-18";
    $date[2025][11][9]["gospel"] = "Luke 8:41-56";

    $date[2025][11][10]["minor"] = "Apostles Olympus, Rhodion, Sosipater, Tertius, Erastes and Quartus - Martyr Orestes";
    $date[2025][11][10]["epistle"] = "1 Thessalonians 1:1-5";
    $date[2025][11][10]["gospel"] = "Luke 12:13-15,22-31";

    $date[2025][11][11]["minor"] = "Martyrs Menas, Victor, Vincent and Stephanida - Father Theodore the Studite";
    $date[2025][11][11]["epistle"] = "1 Thessalonians 1:6-10";
    $date[2025][11][11]["gospel"] = "Luke 12:42-48";

    $date[2025][11][12]["minor"] = "Father John the Merciful - Father Nilus";
    $date[2025][11][12]["epistle"] = "1 Thessalonians 2:1-8";
    $date[2025][11][12]["gospel"] = "Luke 12:48-59";

    $date[2025][11][13]["major"] = "Father John Chrysostom, Archbishop of Constantinople";
    $date[2025][11][13]["orthros"] = "John 10:1-9";
    $date[2025][11][13]["epistle"] = "Hebrews 7:26-28,8:1-2";
    $date[2025][11][13]["gospel"] = "John 10:9-16";

    $date[2025][11][14]["major"] = "Apostle Philip";
    $date[2025][11][14]["epistle"] = "Acts 8:26-39";
    $date[2025][11][14]["gospel"] = "John 1:43-51";

    $date[2025][11][15]["major"] = "Beginning of the Nativity Fast";
    $date[2025][11][15]["minor"] = "Martyrs Gourias, Samonas and Habib";
    $date[2025][11][15]["epistle"] = "2 Corinthians 8:1-5";
    $date[2025][11][15]["gospel"] = "Luke 9:37-43";

    $date[2025][11][16]["major"] = "Eighth Sunday After the Holy Cross";
    $date[2025][11][16]["minor"] = "Apostle Matthew the Evangelist";
    $date[2025][11][16]["tone"] = "Tone 6";
    $date[2025][11][16]["orthros"] = "Matthew 28:16-20 (1)";
    $date[2025][11][16]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][11][16]["gospel"] = "Luke 10:25-37";

    $date[2025][11][17]["minor"] = "Father Gregory the Wonderworker, Bishop of Neo-caesarea";
    $date[2025][11][17]["epistle"] = "1 Thessalonians 2:20,3:1-8";
    $date[2025][11][17]["gospel"] = "Luke 14:1,12-15";

    $date[2025][11][18]["minor"] = "Martyrs Plato and Romanos";
    $date[2025][11][18]["epistle"] = "1 Thessalonians 3:8-13";
    $date[2025][11][18]["gospel"] = "Luke 14:25-35";

    $date[2025][11][19]["minor"] = "Prophet Abadiah - Martyr Barlaam";
    $date[2025][11][19]["epistle"] = "1 Thessalonians 4:1-12";
    $date[2025][11][19]["gospel"] = "Luke 15:1-10";

    $date[2025][11][20]["major"] = "Preparation of the Feast of the Entrance";
    $date[2025][11][20]["minor"] = "Fathers Gregory the Decapolite - Proclus, Archbishop of Constantinople";
    $date[2025][11][20]["epistle"] = "1 Thessalonians 4:18,5:1-10";
    $date[2025][11][20]["gospel"] = "Luke 16:1-9";

    $date[2025][11][21]["major"] = "Entrance of the Mother of God Into the Temple";
    $date[2025][11][21]["orthros"] = "Luke 1:39-49,56";
    $date[2025][11][21]["epistle"] = "Hebrews 9:1-7";
    $date[2025][11][21]["gospel"] = "Luke 10:38-42,11:27-28";

    $date[2025][11][22]["minor"] = "Apostles Philemon, Apphias, Archippus and Onesimus - Martyrs Cecilia, Valerian and Tiburtius";
    $date[2025][11][22]["epistle"] = "2 Corinthians 11:1-6";
    $date[2025][11][22]["gospel"] = "Luke 9:57-62";

    $date[2025][11][23]["major"] = "Ninth Sunday After the Holy Cross";
    $date[2025][11][23]["minor"] = "Fathers Gregory, Bishop of Agrigentium and Amphilochius, Bishop of Iconium";
    $date[2025][11][23]["tone"] = "Tone 7";
    $date[2025][11][23]["orthros"] = "Mark 16:1-8 (2)";
    $date[2025][11][23]["epistle"] = "Ephesians 2:14-22";
    $date[2025][11][23]["gospel"] = "Luke 12:16-22";

    $date[2025][11][24]["minor"] = "Hieromartyrs Clement, Pope of Rome and Peter, Bishop of Alexandria";
    $date[2025][11][24]["epistle"] = "2 Thessalonians 1:1-10";
    $date[2025][11][24]["gospel"] = "Luke 17:20-25";

    $date[2025][11][25]["major"] = "Leave-taking of the Entrance of Mother of God Into the Temple";
    $date[2025][11][25]["minor"] = "Great-martyrs Catherine of Alexandria and Mercury";
    $date[2025][11][25]["orthros"] = "Matthew 25:1-13";
    $date[2025][11][25]["epistle"] = "Galatians 3:23-29,4:1-5";
    $date[2025][11][25]["gospel"] = "Mark 5:24-34";

    $date[2025][11][26]["minor"] = "Fathers Alypius the Stylite and Nikon the Preacher of Penance";
    $date[2025][11][26]["epistle"] = "2 Thessalonians 2:1-12";
    $date[2025][11][26]["gospel"] = "Luke 18:15-17,26-30";

    $date[2025][11][27]["minor"] = "Martyr James the Persian";
    $date[2025][11][27]["epistle"] = "2 Thessalonians 2:13-17,3:1-5";
    $date[2025][11][27]["gospel"] = "Luke 18:31-34";

    $date[2025][11][28]["minor"] = "Martyr Stephen the Latter and Irenarchus";
    $date[2025][11][28]["epistle"] = "2 Thessalonians 3:6-18";
    $date[2025][11][28]["gospel"] = "Luke 19:12-28";

    $date[2025][11][29]["minor"] = "Martyrs Paramon and Philumenes";
    $date[2025][11][29]["epistle"] = "Galatians 1:3-10";
    $date[2025][11][29]["gospel"] = "Luke 10:19-21";

    $date[2025][11][30]["major"] = "Thirteenth Sunday After the Holy Cross";
    $date[2025][11][30]["minor"] = "Apostle Andrew, the First-called";
    $date[2025][11][30]["tone"] = "Tone 8";
    $date[2025][11][30]["orthros"] = "Mark 16:9-20 (3)";
    $date[2025][11][30]["epistle"] = "1 Corinthians 4:9-16";
    $date[2025][11][30]["gospel"] = "Luke 18:18-27";

    $date[2025][12][1]["minor"] = "Prophet Nahum";
    $date[2025][12][1]["epistle"] = "1 Timothy 1:1-7";
    $date[2025][12][1]["gospel"] = "Luke 19:37-44";

    $date[2025][12][2]["minor"] = "Prophet Habakkuk";
    $date[2025][12][2]["epistle"] = "1 Timothy 1:8-14";
    $date[2025][12][2]["gospel"] = "Luke 19:45-48";

    $date[2025][12][3]["minor"] = "Prophet Zephaniah";
    $date[2025][12][3]["epistle"] = "1 Timothy 1:18-20,2:8-15";
    $date[2025][12][3]["gospel"] = "Luke 20:1-8";

    $date[2025][12][4]["major"] = "Great-martyr Barbara";
    $date[2025][12][4]["minor"] = "Father John the Damascene";
    $date[2025][12][4]["epistle"] = "Galatians 3:23-29,4:1-5";
    $date[2025][12][4]["gospel"] = "Mark 5:24-34";

    $date[2025][12][5]["major"] = "Father Sabas the Sanctified";
    $date[2025][12][5]["orthros"] = "Luke 6:17-23";
    $date[2025][12][5]["epistle"] = "Galatians 5:22-26,6:1-2";
    $date[2025][12][5]["gospel"] = "Matthew 11:27-30";

    $date[2025][12][6]["major"] = "Father Nicholas Fhe Wonderworker";
    $date[2025][12][6]["orthros"] = "John 10:1-9";
    $date[2025][12][6]["epistle"] = "Hebrews 13:17-21";
    $date[2025][12][6]["gospel"] = "Luke 6:17-23";

    $date[2025][12][7]["major"] = "Tenth Sunday After the Holy Cross";
    $date[2025][12][7]["minor"] = "Father Ambrose, Bishop of Milan";
    $date[2025][12][7]["tone"] = "Tone 1";
    $date[2025][12][7]["orthros"] = "Luke 24:1-12 (4)";
    $date[2025][12][7]["epistle"] = "Ephesians 5:8-19";
    $date[2025][12][7]["gospel"] = "Luke 13:10-17";

    $date[2025][12][8]["minor"] = "Father Patapios";
    $date[2025][12][8]["epistle"] = "1 Timothy 5:1-12";
    $date[2025][12][8]["gospel"] = "Luke 20:27-44";

    $date[2025][12][9]["major"] = "Maternity of Ann";
    $date[2025][12][9]["orthros"] = "Luke 6:17-23";
    $date[2025][12][9]["epistle"] = "Galatians 4:22-27";
    $date[2025][12][9]["gospel"] = "Luke 8:16-21";

    $date[2025][12][10]["minor"] = "Martyrs Mena, Hermogenes and Eugraphus";
    $date[2025][12][10]["epistle"] = "1 Timothy 5:22-25,6:1-11";
    $date[2025][12][10]["gospel"] = "Luke 21:5-8,10-11,20-24";

    $date[2025][12][11]["minor"] = "Father Daniel the Stylite";
    $date[2025][12][11]["epistle"] = "1 Timothy 6:17-21";
    $date[2025][12][11]["gospel"] = "Luke 21:28-33";

    $date[2025][12][12]["major"] = "Father Spiridon the Wonderworker";
    $date[2025][12][12]["orthros"] = "John 10:1-9";
    $date[2025][12][12]["epistle"] = "Ephesians 5:8-19";
    $date[2025][12][12]["gospel"] = "John 10:9-16";

    $date[2025][12][13]["minor"] = "Martyrs Eustrates, Auxentius, Eugene, Mardarius, Orestes and the Virgin Lucia";
    $date[2025][12][13]["epistle"] = "Galatians 5:22-26,6:1-2";
    $date[2025][12][13]["gospel"] = "Luke 13:19-29";

    $date[2025][12][14]["major"] = "Sunday of the Forefathers";
    $date[2025][12][14]["minor"] = "Martyrs Thyrces, Leucius, Callinicus, Philemon and Apollonius";
    $date[2025][12][14]["tone"] = "Tone 2";
    $date[2025][12][14]["orthros"] = "Luke 24:12-35 (5)";
    $date[2025][12][14]["epistle"] = "Colossians 3:4-11";
    $date[2025][12][14]["gospel"] = "Luke 14:16-24";

    $date[2025][12][15]["minor"] = "Hieromartyr Eleutherius - Father Paul of Latra";
    $date[2025][12][15]["epistle"] = "2 Timothy 2:20-26";
    $date[2025][12][15]["gospel"] = "Mark 8:11-21";

    $date[2025][12][16]["minor"] = "Prophet Haggai";
    $date[2025][12][16]["epistle"] = "2 Timothy 3:16-17,4:1-4";
    $date[2025][12][16]["gospel"] = "Mark 8:22-26";

    $date[2025][12][17]["minor"] = "Prophet Daniel and Ananias, Azarias and Mizael";
    $date[2025][12][17]["epistle"] = "2 Timothy 4:9-22";
    $date[2025][12][17]["gospel"] = "Mark 8:30-34";

    $date[2025][12][18]["minor"] = "Martyrs Sebastian and His Companions";
    $date[2025][12][18]["epistle"] = "Titus 1:5-14";
    $date[2025][12][18]["gospel"] = "Mark 9:9-15";

    $date[2025][12][19]["minor"] = "Martyr Boniface";
    $date[2025][12][19]["epistle"] = "Titus 1:15-16,2:1-10";
    $date[2025][12][19]["gospel"] = "Mark 9:32-40";

    $date[2025][12][20]["major"] = "Saturday Before the Nativity of our Lord";
    $date[2025][12][20]["minor"] = "Hieromartyr Ignatius the God-bearer";
    $date[2025][12][20]["epistle"] = "Galatians 3:8-12";
    $date[2025][12][20]["gospel"] = "Luke 13:19-29";

    $date[2025][12][21]["major"] = "Sunday Before the Nativity of our Lord - Genealogy";
    $date[2025][12][21]["minor"] = "Martyr Juliana of Nicomedia";
    $date[2025][12][21]["tone"] = "Tone 3";
    $date[2025][12][21]["orthros"] = "Luke 24:36-53 (6)";
    $date[2025][12][21]["epistle"] = "Hebrews 11:9-10,32-40";
    $date[2025][12][21]["gospel"] = "Matthew 1:1-25";

    $date[2025][12][22]["minor"] = "Great-martyr Anastasia";
    $date[2025][12][22]["epistle"] = "Hebrews 3:5-11,17-19";
    $date[2025][12][22]["gospel"] = "Mark 9:42-49,10:1";

    $date[2025][12][23]["minor"] = "Ten Holy Martyrs of Crete";
    $date[2025][12][23]["epistle"] = "Hebrews 4:1-13";
    $date[2025][12][23]["gospel"] = "Mark 10:2-12";

    $date[2025][12][24]["major"] = "Paramony of the Nativity";
    $date[2025][12][24]["minor"] = "Martyr Eugenia";
    $date[2025][12][24]["epistle"] = "Hebrews 1:1-12";
    $date[2025][12][24]["gospel"] = "Luke 2:1-20";

    $date[2025][12][25]["major"] = "Nativity of our Lord";
    $date[2025][12][25]["orthros"] = "Matthew 1:18-25";
    $date[2025][12][25]["epistle"] = "Galatians 4:4-7";
    $date[2025][12][25]["gospel"] = "Matthew 2:1-12";

    $date[2025][12][26]["major"] = "Synaxis of the Mother of God";
    $date[2025][12][26]["epistle"] = "Hebrews 10:19-31";
    $date[2025][12][26]["gospel"] = "Matthew 2:13-23";

    $date[2025][12][27]["major"] = "Saturday After the Nativity of our Lord";
    $date[2025][12][27]["minor"] = "Protomartyr Archdeacon Stephen";
    $date[2025][12][27]["epistle"] = "Acts 6:8-15,7:1-5,47-60";
    $date[2025][12][27]["gospel"] = "Matthew 12:15-21";

    $date[2025][12][28]["major"] = "Sunday After the Nativity of our Lord - Holy Joseph, James and David";
    $date[2025][12][28]["tone"] = "Tone 4";
    $date[2025][12][28]["orthros"] = "John 20:1-10 (7)";
    $date[2025][12][28]["epistle"] = "Galatians 1:11-19";
    $date[2025][12][28]["gospel"] = "Luke 18:35-42";

    $date[2025][12][29]["minor"] = "Innocents Put To Death in Bethelehem - Father Marcellus, Abbot";
    $date[2025][12][29]["epistle"] = "Hebrews 8:7-13";
    $date[2025][12][29]["gospel"] = "Mark 10:46-52";

    $date[2025][12][30]["minor"] = "Venerable Melany - Martyr Anysia";
    $date[2025][12][30]["epistle"] = "Hebrews 9:8-23";
    $date[2025][12][30]["gospel"] = "Mark 11:11-23";

    $date[2025][12][31]["major"] = "Leave-taking of the Nativity of our Lord";
    $date[2025][12][31]["epistle"] = "Hebrews 10:1-18";
    $date[2025][12][31]["gospel"] = "Mark 11:22-26";

    return $date[date("Y", $time)][date("n", $time)][date("j", $time)];
  }
}

/*

major,minor,orthros,epistle,gospel: [melkite_lectionary date="2025-1-1"]

minor,epistle,gospel: [melkite_lectionary date="2025-1-2"]

major,minor,epistle,gospel: [melkite_lectionary date="2025-1-3"]

major,minor,tone,orthros,epistle,gospel: [melkite_lectionary date="2025-1-5"]

major,orthros,epistle,gospel: [melkite_lectionary date="2025-1-6"]

major,epistle,gospel: [melkite_lectionary date="2025-1-7"]

minor,orthros,epistle,gospel: [melkite_lectionary date="2025-1-29"]

major,tone,orthros,epistle,gospel: [melkite_lectionary date="2025-2-2"]

minor,vespers: [melkite_lectionary date="2025-2-26"]

major,minor,noon,vespers: [melkite_lectionary date="2025-3-3"]

minor,noon,vespers: [melkite_lectionary date="2025-3-4"]

 */

?>
